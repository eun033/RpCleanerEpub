import http from 'node:http';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {BridgeError,check,equal} from './auth.mjs';
import {JobBridge} from './jobs.mjs';
export const DEFAULT_PORT=17446;
const ROOT=fileURLToPath(new URL('./',import.meta.url));
const PUBLIC_RELEASE_API='https://api.github.com/repos/eun033/RpCleanerEpub/contents/main/gpt-bridge?ref=main';
const PUBLIC_VERSION_API='https://api.github.com/repos/eun033/RpCleanerEpub/contents/main/gpt-bridge/version.json?ref=main';
const LEGACY_RELEASE_API='https://api.github.com/repos/eun033/RpCleanerEpub/contents/main/wish-core-hap-gpt?ref=main';
const LEGACY_PACKAGE_API='https://api.github.com/repos/eun033/RpCleanerEpub/contents/main/wish-core-hap-gpt/termux-bridge/package.json?ref=main';
function send(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
async function readBody(req){let bytes=0;const chunks=[];for await(const chunk of req){bytes+=chunk.length;check(bytes<=5000000,'BODY_SIZE','요청이 너무 큽니다.',413);chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');}catch{throw new BridgeError('JSON','요청 JSON을 확인하세요.');}}
function command(file,args,cwd){return new Promise((resolve,reject)=>{const child=spawn(file,args,{cwd,stdio:['ignore','pipe','pipe']}),chunks=[];for(const stream of [child.stdout,child.stderr])stream.on('data',chunk=>{if(chunks.reduce((n,x)=>n+x.length,0)<100000)chunks.push(chunk);});child.on('error',reject);child.on('close',code=>code===0?resolve(Buffer.concat(chunks).toString('utf8').trim()):reject(new BridgeError('UPDATE_FAILED','업데이트 명령을 실행하지 못했습니다. 인터넷 연결과 설치 상태를 확인하세요. ('+Buffer.concat(chunks).toString('utf8').trim().split('\n').slice(-1)[0]+')',500)));});}
export function commandLookup(name,platform=process.platform){return platform==='win32'?{file:'where.exe',args:[name]}:{file:'sh',args:['-c','command -v "$1" >/dev/null 2>&1','sh',name]};}
function commandExists(name,platform=process.platform){return new Promise(resolve=>{const lookup=commandLookup(name,platform),child=spawn(lookup.file,lookup.args,{stdio:'ignore'});child.on('error',()=>resolve(false));child.on('close',code=>resolve(code===0));});}
export function gitSourceCandidates({runtimeSource,explicit='',marker='',home=os.homedir()}={}){return [...new Set([explicit,marker,runtimeSource,path.join(home,'gpt-codex-work','gpt-brige-crack','bridge-main'),path.join(home,'gpt-codex-work','work-hap-gpt','termux-bridge'),path.join(home,'RpCleanerEpub','main','wish-core-hap-gpt','termux-bridge')].filter(Boolean).map(value=>path.resolve(value)))];}
export function classifyUpdate({local,remote,base,dirty,currentVersion,latestVersion,localTree='',remoteTree=''}){
  if(dirty)return 'local_changes';
  if(currentVersion===latestVersion&&(local===remote||localTree&&localTree===remoteTree))return 'current';
  if(base===local||local===remote)return 'available';
  if(base===remote)return 'local_ahead';
  return 'diverged';
}
export function compareVersions(a,b){const left=String(a).split('.').map(Number),right=String(b).split('.').map(Number);for(let i=0;i<Math.max(left.length,right.length);i++){const difference=(left[i]||0)-(right[i]||0);if(difference)return Math.sign(difference);}return 0;}
export function selectZipRelease(entries,name='GPT_Bridge.zip'){return entries.find(entry=>entry?.name===name&&String(entry.download_url||'').startsWith('https://raw.githubusercontent.com/eun033/RpCleanerEpub/')&&String(entry.git_url||'').startsWith('https://api.github.com/repos/eun033/RpCleanerEpub/git/blobs/'))||null;}
export function zipSourcePrefix(entries){
  if(!entries.length||entries.some(entry=>entry.includes('\\')||entry.split('/').includes('..')))return '';
  for(const [root,prefix] of [['gpt-bridge/','gpt-bridge/'],['wish-core-hap-gpt/','wish-core-hap-gpt/termux-bridge/']])if(entries.every(entry=>entry.startsWith(root))&&['package.json','update-termux.sh','src/start.mjs','src/server.mjs'].every(file=>entries.includes(prefix+file)))return prefix;
  return '';
}
export function validZipEntries(entries){return !!zipSourcePrefix(entries);}
export async function checkPublicZipUpdate(fetchImpl,currentVersion){
  const options={headers:{Accept:'application/vnd.github+json'},cache:'no-store'};
  for(const source of [{listing:PUBLIC_RELEASE_API,version:PUBLIC_VERSION_API,archive:'GPT_Bridge.zip'},{listing:LEGACY_RELEASE_API,version:LEGACY_PACKAGE_API,archive:'Wish_RP_Core_HAP_GPT.zip'}]){
    const [listingResponse,versionResponse]=await Promise.all([fetchImpl(source.listing,options),fetchImpl(source.version,options)]);
    if(!listingResponse.ok||!versionResponse.ok)continue;
    const release=selectZipRelease(await listingResponse.json(),source.archive),versionFile=await versionResponse.json();
    let latest=null;try{latest=JSON.parse(Buffer.from(versionFile?.content||'',versionFile?.encoding||'base64').toString('utf8'));}catch{}
    if(!release||!(/^[0-9a-f]{40}$/.test(release.sha||''))||!release.git_url.endsWith('/'+release.sha)||latest?.name!=='local-gpt-subscription-bridge'||!/^\d+\.\d+\.\d+$/.test(latest.version||'')||(latest.archive&&latest.archive!==source.archive))continue;
    const comparison=compareVersions(currentVersion,latest.version),status=comparison<0?'available':comparison>0?'local_ahead':'current';
    return {method:'zip',status,current_version:currentVersion,latest_version:latest.version,archive:release.name,archive_sha:release.sha,download_url:release.git_url,checked_at:Date.now()};
  }
  throw new BridgeError('UPDATE_CHECK','공개 ZIP 버전을 확인하지 못했습니다.',502);
}
const BRIDGE_FILES=['package.json','version.json','src','start-windows.ps1','start-windows.bat','start.sh','start-ish.sh','update-termux.sh','install-termux.sh','install-ish.sh','ish','LICENSE','README.md','VALIDATION.md','examples'];
async function copyBridgeFiles(source,target){await fs.mkdir(target,{recursive:true});for(const file of BRIDGE_FILES){const from=path.join(source,file);if(await fs.stat(from).then(()=>true,()=>false))await fs.cp(from,path.join(target,file),{recursive:true,force:true});}}
async function powershellCommand(exists,platform){if(platform!=='win32')return '';for(const name of ['powershell.exe','pwsh.exe','pwsh'])if(await exists(name,platform))return name;return '';}
export async function applyPublicZipUpdate(fetchImpl,state,{platform=process.platform,runtimeSource='',commandImpl=command,commandExistsImpl=commandExists}={}){
  const temporary=await fs.mkdtemp(path.join(os.tmpdir(),'gpt-bridge-update-')),archive=path.join(temporary,'release.zip'),extractDir=path.join(temporary,'extracted');
  try{
    const powershell=await powershellCommand(commandExistsImpl,platform);
    if(platform==='win32')check(powershell,'UPDATE_TOOL','Windows PowerShell 또는 PowerShell 7을 찾지 못했습니다.',500);
    else if(!await commandExistsImpl('unzip',platform)){check(await commandExistsImpl('pkg',platform),'UPDATE_TOOL','ZIP 압축 해제 도구를 설치할 수 없는 환경입니다.',500);await commandImpl('pkg',['install','-y','unzip'],temporary);}
    const response=await fetchImpl(state.download_url,{headers:{Accept:'application/vnd.github+json'},cache:'no-store'}),declared=Number(response.headers.get('content-length')||0);
    check(response.ok&&(!declared||declared<=45*1024*1024),'UPDATE_DOWNLOAD','공개 ZIP 파일을 내려받지 못했습니다.',502);
    const envelope=Buffer.from(await response.arrayBuffer());check(envelope.length>0&&envelope.length<=45*1024*1024,'UPDATE_DOWNLOAD','공개 ZIP 응답 크기를 확인할 수 없습니다.',502);
    let payload=null;try{payload=JSON.parse(envelope.toString('utf8'));}catch{}
    check(payload?.sha===state.archive_sha&&payload?.encoding==='base64'&&typeof payload.content==='string'&&/^[A-Za-z0-9+/=\s]+$/.test(payload.content),'UPDATE_DOWNLOAD','공개 ZIP 응답을 확인하지 못했습니다.',502);
    const bytes=Buffer.from(payload.content.replace(/\s/g,''),'base64'),blobSha=createHash('sha1').update('blob '+bytes.length+'\0').update(bytes).digest('hex');
    check(bytes.length>0&&bytes.length<=32*1024*1024&&blobSha===state.archive_sha,'UPDATE_DOWNLOAD','공개 ZIP 파일 무결성을 확인하지 못했습니다.',502);await fs.writeFile(archive,bytes,{mode:0o600});
    let entries;
    if(platform==='win32'){
      const script=path.join(temporary,'archive.ps1');
      await fs.writeFile(script,"param([ValidateSet('List','Extract')][string]$Mode,[string]$Archive,[string]$Destination)\nAdd-Type -AssemblyName System.IO.Compression.FileSystem\nif($Mode -eq 'List'){$zip=[IO.Compression.ZipFile]::OpenRead($Archive);try{foreach($entry in $zip.Entries){[Console]::Out.WriteLine($entry.FullName)}}finally{$zip.Dispose()}}else{[IO.Compression.ZipFile]::ExtractToDirectory($Archive,$Destination)}\n",'utf8');
      entries=(await commandImpl(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-Mode','List','-Archive',archive,'-Destination',extractDir],temporary)).split(/\r?\n/).filter(Boolean);
      check(validZipEntries(entries),'UPDATE_ARCHIVE','ZIP 내부 경로를 확인하지 못했습니다.',422);
      await commandImpl(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-Mode','Extract','-Archive',archive,'-Destination',extractDir],temporary);
    }else{
      entries=(await commandImpl('unzip',['-Z1',archive],temporary)).split(/\r?\n/).filter(Boolean);
      check(validZipEntries(entries),'UPDATE_ARCHIVE','ZIP 내부 경로를 확인하지 못했습니다.',422);
      await commandImpl('unzip',['-q',archive,'-d',extractDir],temporary);
    }
    const prefix=zipSourcePrefix(entries);check(prefix,'UPDATE_ARCHIVE','ZIP 내부 경로를 확인하지 못했습니다.',422);
    const source=path.join(extractDir,...prefix.slice(0,-1).split('/')),manifest=JSON.parse(await fs.readFile(path.join(source,'package.json'),'utf8'));
    check(manifest.name==='local-gpt-subscription-bridge'&&manifest.version===state.latest_version,'UPDATE_ARCHIVE','ZIP의 브리지 버전이 확인 결과와 다릅니다.',422);
    if(platform==='win32'){check(runtimeSource,'UPDATE_SOURCE','현재 브리지 설치 경로를 확인하지 못했습니다.',500);await copyBridgeFiles(source,runtimeSource);}
    else await commandImpl('bash',[path.join(source,'update-termux.sh')],source);
    return {updated:true,method:'zip',message:'공개 ZIP 버전을 적용했습니다. 서버를 다시 시작합니다.'};
  }finally{await fs.rm(temporary,{recursive:true,force:true});}
}
export async function applyGitUpdate(gitInfo,runtimeSource,{platform=process.platform,commandImpl=command}={}){
  const {source,repo,branch}=gitInfo;await commandImpl('git',['pull','--ff-only','origin',branch],repo);
  if(path.resolve(source)!==path.resolve(runtimeSource)){if(platform==='win32')await copyBridgeFiles(source,runtimeSource);else await commandImpl('bash',[path.join(source,'update-termux.sh')],source);}
  return {updated:true,method:'git',message:'Git 버전을 적용했습니다. 서버를 다시 시작합니다.'};
}
export function restartServer({server,bridge},exit=code=>process.exit(code)){
  bridge.close();
  // Incomplete HTTP requests can otherwise keep close() waiting indefinitely.
  const drain=setTimeout(()=>server.closeAllConnections(),1000);
  server.close(()=>{clearTimeout(drain);exit(75);});
}
export async function createServer({dir=path.join(os.homedir(),'.local-gpt-subscription-bridge'),fetchImpl=globalThis.fetch,clock=Date.now,appName='Local GPT Subscription Bridge',onRestart=null,onUpdateCheck=null,onUpdate=null,updateMethods=[],installMethod=''}={}){
  const bridge=await new JobBridge(dir,{fetchImpl,clock,appName}).init();
  const instanceId=randomUUID();
  let updateBusy=false;const restartBusy=()=>updateBusy||bridge.running||[...bridge.jobs.values()].some(job=>['queued','running'].includes(job.status));
  const server=http.createServer(async(req,res)=>{
    const port=server.address()?.port,base='http://127.0.0.1:'+port;
    res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');
    if(req.headers.host!=='127.0.0.1:'+port)return send(res,403,{code:'HOST',message:'127.0.0.1 주소로 연결하세요.'});
    const origin=req.headers.origin;
    // Cross-origin API calls still require the installation's random pair code.
    if(origin&&/^https?:\/\//.test(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');}
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type'});res.end();return;}
    try{
      const url=new URL(req.url,base);
      if(url.pathname==='/auth/callback'&&req.method==='GET'){
        await bridge.auth.finishLogin(url);res.writeHead(303,{Location:'/#pair='+bridge.auth.identity.pair});res.end();return;
      }
      const assets={'/':['dashboard.html','text/html'],'/app.js':['dashboard.js','application/javascript']};
      if(req.method==='GET'&&Object.hasOwn(assets,url.pathname)){
        const [file,type]=assets[url.pathname];res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
        res.writeHead(200,{'Content-Type':type+'; charset=utf-8'});res.end(await fs.readFile(path.join(ROOT,file)));return;
      }
      check(equal(req.headers.authorization||'','Bearer '+bridge.auth.identity.pair),'PAIR','관리 화면에서 복사한 로컬 연결 코드가 필요합니다.',401);
      const methods=updateMethods.length?updateMethods:typeof onUpdate==='function'?['git']:[];
      if(req.method==='GET'&&url.pathname==='/api/status'){
        let range;
        if(url.searchParams.has('week_start_at')||url.searchParams.has('week_end_at')){
          const start=Number(url.searchParams.get('week_start_at')),end=Number(url.searchParams.get('week_end_at'));
          check(url.searchParams.has('week_start_at')&&url.searchParams.has('week_end_at')&&Number.isSafeInteger(start)&&Number.isSafeInteger(end)&&Math.abs(start)<=8640000000000000&&Math.abs(end)<=8640000000000000&&end-start>=6*86400000&&end-start<=8*86400000,'USAGE_RANGE','주간 집계 범위를 확인해 주세요.');
          range={week_start_at:start,week_end_at:end};
        }
        return send(res,200,{...bridge.status(range),instance_id:instanceId,can_restart:typeof onRestart==='function',restart_busy:restartBusy(),can_update:typeof onUpdate==='function',install_method:installMethod||methods[0]||'unknown',update_methods:methods,update_busy:updateBusy});
      }
      if(req.method==='GET'&&url.pathname==='/api/update/check'){
        const method=url.searchParams.get('method')||methods[0];
        check(typeof onUpdateCheck==='function'&&methods.includes(method),'UPDATE_UNAVAILABLE','현재 설치 방식에서 사용할 수 없는 업데이트입니다.',409);
        check(!updateBusy,'BUSY','업데이트 작업이 끝난 뒤 다시 확인하세요.',409);
        updateBusy=true;try{return send(res,200,await onUpdateCheck(method));}finally{updateBusy=false;}
      }
      if(req.method==='GET'&&url.pathname==='/api/models')return send(res,200,await bridge.auth.models());
      if(req.method==='POST'&&url.pathname==='/api/login'){check(!bridge.running,'BUSY','진행 중인 작업이 끝난 뒤 로그인하세요.',409);return send(res,200,{url:bridge.auth.startLogin(port)});}
      if(req.method==='POST'&&url.pathname==='/api/logout'){check(!bridge.running,'BUSY','진행 중인 작업이 끝난 뒤 연결을 해제하세요.',409);await bridge.auth.logout();await bridge.settingsChange({paused:true});return send(res,200,{ok:true});}
      if(req.method==='POST'&&url.pathname==='/api/settings')return send(res,200,await bridge.settingsChange(await readBody(req)));
      if(req.method==='POST'&&url.pathname==='/api/restart'){
        check(typeof onRestart==='function','RESTART_UNAVAILABLE','start.sh 또는 start-windows.ps1로 서버를 실행한 경우에만 관리 화면에서 재시작할 수 있습니다.',409);
        check(!restartBusy(),'BUSY','대기·진행 중인 작업이 끝난 뒤 재시작하세요.',409);
        send(res,202,{ok:true});setImmediate(()=>onRestart({server,bridge}));return;
      }
      if(req.method==='POST'&&url.pathname==='/api/update'){
        const method=(await readBody(req)).method||methods[0];
        check(typeof onUpdate==='function'&&methods.includes(method),'UPDATE_UNAVAILABLE','현재 설치 방식에서 사용할 수 없는 업데이트입니다.',409);
        check(!restartBusy(),'BUSY','대기·진행 중인 작업이 끝난 뒤 업데이트하세요.',409);
        updateBusy=true;try{const result=await onUpdate(method);send(res,200,{ok:true,...result});if(result.updated!==false)setImmediate(()=>onRestart({server,bridge}));}finally{updateBusy=false;}return;
      }
      if(req.method==='POST'&&url.pathname==='/api/jobs')return send(res,202,await bridge.add(await readBody(req)));
      const match=url.pathname.match(/^\/api\/jobs\/([A-Za-z0-9_-]{16,100})(?:\/(resume))?$/);
      if(match&&req.method==='GET'&&!match[2])return send(res,200,bridge.get(match[1]));
      if(match&&req.method==='POST'&&match[2]==='resume')return send(res,200,await bridge.resume(match[1]));
      send(res,404,{code:'PATH',message:'없는 경로입니다.'});
    }catch(error){send(res,error instanceof BridgeError?error.status:500,{code:error instanceof BridgeError?error.code:'LOCAL_ERROR',message:error instanceof BridgeError?error.message:'로컬 처리 중 오류가 발생했습니다. 같은 요청을 자동으로 다시 보내지 마세요.'});}
  });
  return {server,bridge};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.env.GPT_BRIDGE_PORT||DEFAULT_PORT);
  check(Number.isInteger(port)&&port>=1024&&port<=65535,'PORT','사용할 포트를 확인하세요.');
  const supervised=process.env.GPT_BRIDGE_SUPERVISED==='1',runtimeSource=path.resolve(ROOT,'..'),manifestPath=path.join(runtimeSource,'package.json');
  const restart=supervised?restartServer:null;
  const marker=await fs.readFile(path.join(runtimeSource,'.git-source'),'utf8').then(value=>value.trim(),()=>''),candidates=gitSourceCandidates({runtimeSource,explicit:process.env.GPT_BRIDGE_SOURCE,marker});
  let gitInfo=null;
  if(await commandExists('git'))for(const candidate of candidates)try{
    const source=candidate,repo=await command('git',['-C',source,'rev-parse','--show-toplevel'],source),branch=await command('git',['-C',repo,'branch','--show-current'],repo),sourcePath=path.relative(repo,source).split(path.sep).join('/')||'.',packageFile=path.posix.join(sourcePath,'package.json');
    check(branch&&await fs.stat(path.join(source,'update-termux.sh')).then(stat=>stat.isFile(),()=>false),'UPDATE_SOURCE','업데이트 원본을 확인하지 못했습니다.',409);gitInfo={source,repo,branch,sourcePath,packageFile};break;
  }catch{}
  const updateMethods=supervised?[gitInfo?'git':'zip']:[];
  const checkGitUpdate=gitInfo?async()=>{
    const {source,repo,branch,sourcePath,packageFile}=gitInfo;await command('git',['fetch','--quiet','origin','refs/heads/'+branch+':refs/remotes/origin/'+branch],repo);
    const [local,remote,base,dirty,currentPackage,latestPackage,localTree,remoteTree]=await Promise.all([
      command('git',['rev-parse','HEAD'],repo),command('git',['rev-parse','origin/'+branch],repo),command('git',['merge-base','HEAD','origin/'+branch],repo),command('git',['status','--porcelain','--untracked-files=no'],repo),
      fs.readFile(manifestPath,'utf8'),command('git',['show','origin/'+branch+':'+packageFile],repo),command('git',['rev-parse','HEAD:'+sourcePath],repo),command('git',['rev-parse','origin/'+branch+':'+sourcePath],repo)
    ]);
    const currentVersion=JSON.parse(currentPackage).version,latestVersion=JSON.parse(latestPackage).version;
    const status=classifyUpdate({local,remote,base,dirty,currentVersion,latestVersion,localTree,remoteTree});
    return {method:'git',status,current_version:currentVersion,latest_version:latestVersion,current_commit:local.slice(0,7),latest_commit:remote.slice(0,7),checked_at:Date.now()};
  }:null;
  const currentVersion=async()=>JSON.parse(await fs.readFile(manifestPath,'utf8')).version;
  const checkUpdate=updateMethods.length?async method=>method==='git'?checkGitUpdate():checkPublicZipUpdate(globalThis.fetch,await currentVersion()):null;
  const stateError=state=>({current:'이미 최신 버전입니다.',local_changes:'저장소에 직접 수정한 파일이 있어 자동 업데이트하지 않았습니다.',local_ahead:'현재 설치본이 공개 버전보다 새롭거나 로컬 커밋이 앞서 있습니다.',diverged:'로컬과 원격 기록이 갈라져 자동 업데이트하지 않았습니다.'})[state.status]||'업데이트 상태를 다시 확인하세요.';
  const update=updateMethods.length?async method=>{
    const state=await checkUpdate(method);check(state.status==='available','UPDATE_STATE',stateError(state),409);
    if(method==='zip')return applyPublicZipUpdate(globalThis.fetch,state,{runtimeSource});
    return applyGitUpdate(gitInfo,runtimeSource);
  }:null;
  const {server,bridge}=await createServer({onRestart:restart,onUpdateCheck:checkUpdate,onUpdate:update,updateMethods,installMethod:gitInfo?'git':supervised?'zip':'unknown'});
  const version=await currentVersion();server.listen(port,'127.0.0.1',()=>console.log('\nGPT 브리지 '+version+'\n관리 화면: http://127.0.0.1:'+port+'/#pair='+bridge.auth.identity.pair+'\n각자 본인 계정으로 로그인하세요. 종료: Ctrl+C\n'));
  server.on('error',error=>{bridge.close();console.error(error.code==='EADDRINUSE'?'해당 포트가 이미 사용 중입니다. 기존 서버를 확인하거나 GPT_BRIDGE_PORT를 바꾸세요.':'서버를 시작하지 못했습니다.');process.exitCode=1;});
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{bridge.close();server.close(()=>process.exit(0));});
}
