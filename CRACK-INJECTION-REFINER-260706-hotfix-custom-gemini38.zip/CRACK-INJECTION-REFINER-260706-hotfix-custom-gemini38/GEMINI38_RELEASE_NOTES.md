# Gemini 3.8 Flash 추가 버전 — 작업 및 검증 결과

작성일: 2026-09-03

- 버전: `1.4.0.260903-custom.3`
- 설치 파일: [erie_crack_inject_universal_gemini38_backup_choice.user.js](D:/_GG/erie_crack_inject_universal_gemini38_backup_choice.user.js)
- 수정 소스: `D:\_GG\CRACK-INJECTION-REFINER-260706-hotfix-custom-gemini38`
- 기준: 기존 `1.4.0.260820-custom.2` 커스텀 소스의 별도 복사본.
- 원본 스크립트, 이전 3.6/3.7 설치 파일 및 이전 소스 폴더는 수정하지 않음.

## 반영 내용

1. 공식 ID `gemini-3.8-flash`를 추출/변환, 후보 재정렬, 과거 장면 판단, 응답 교정의 모델 선택기에 추가했다. 전체 추출·장면 기억·지식 변환·병합은 기존처럼 공통 생성 모델을 사용한다. 기존 모델과 기본 모델은 그대로다.
2. 기존 `generateContent` 호출 구조를 유지했다. Developer API는 `v1beta/models/gemini-3.8-flash:generateContent`, Vertex는 기존 `global` 경로를 사용한다. Firebase도 기존 `VertexAIBackend('global')`를 유지했다. 모델 이름을 다른 제공자의 이름으로 임의 치환하지 않았다.
3. 3.8의 추론 수준은 `low / medium / high`, 기본은 `medium`이다. 해당 모델에서는 UI의 `minimal` 선택을 제외하고, 저장된 `minimal / off` 값은 요청할 때 `low`로 변환한다. 구형 예산 설정도 기존 수준 변환 기준에 맞춰 처리하며 `thinkingBudget`은 전송하지 않는다. 저장된 설정 자체는 자동으로 덮어쓰지 않는다. 직접 호출 및 가져오기 기능의 보조 요청 경로에도 같은 방어 처리를 적용했다.
4. 모델을 바꾸면 해당 기능의 추론 선택지가 즉시 갱신된다. Firebase SDK에는 대문자 수준값을 전달한다. 기존 SDK 12.8.0은 유지했다.
5. 기존 Gemini 요청은 추론 설정, JSON MIME 형식, 명시적인 출력 한도만 구성하므로 sampling 파라미터를 추가하지 않았다. 비어 있는 3.8 입력은 서버 호출 전에 설명과 함께 거부한다.
6. 기존 텍스트·JSON 응답 파서를 재사용한다. Firebase 3.8 응답에서도 생각 부분을 일반 출력에서 제외하고, 빈 응답의 종료/차단 사유를 표시한다. 추론 토큰과 캐시 토큰을 비용에 반영하며, 사용량이 없으면 추정치임을 기록한다.
7. 이전 백업 옵션인 **가져오지 않기 / 없는 채팅 가져오기 / 백업 기준으로 전체 교체** 및 기본값 **가져오지 않기**는 그대로 보존했다.

모델 ID, 지원 추론 수준, 입력 1,048,576 / 출력 65,536 토큰 한도, JSON 및 함수 호출 지원은 [Google 모델 문서](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash)에서 확인했다. 이 프로그램은 텍스트를 하나의 user 메시지로 보내며, 별도 함수 호출·도구 결과·다중 모달·스트리밍은 구현되어 있지 않아 새로 추가하지 않았다. 메시지/파라미터 제한은 [Google 마이그레이션 지침](https://ai.google.dev/gemini-api/docs/generate-content/latest-model)과 [Vertex 개발 가이드](https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/guides/gemini-3-8-flash)를 대조했다.

## 비용 처리

Google의 일반 유료 요청 기준, 100만 토큰당 USD 추정 비용이다.

| 기간 | 일반 입력 | 캐시 입력 | 출력 + 추론 |
| --- | ---: | ---: | ---: |
| 2026-12-31까지 | 0.75 | 0.075 | 3.75 |
| 2027-01-01부터 | 1.50 | 0.15 | 7.50 |

[Developer API 가격](https://ai.google.dev/gemini-api/docs/pricing) 및 [Vertex global 가격](https://cloud.google.com/gemini-enterprise-agent-platform/generative-ai/pricing)을 적용했다. Firebase는 현재 코드가 Vertex global을 이용하므로 같은 기준을 사용한다. Vertex 도입 프로모션은 크레딧 환급 방식이므로 청구 화면의 할인 전 금액과 다를 수 있다.

새 이벤트는 호출 시각에 맞는 요금을 사용하며, 2027년 전환 기준은 UTC다. 이미 저장한 비용은 재계산하지 않는다. 출력 토큰은 `candidatesTokenCount + thoughtsTokenCount`, 입력 캐시는 `cachedContentTokenCount`를 활용한다. 임의 OpenAI 호환 서버가 같은 모델 이름을 반환하더라도 Google 가격을 확정 적용하지 않고 요금 미상으로 기록한다. 무료 할당량·세금·환율·개별 계약·별도 서비스 요금은 이 추정에 포함되지 않는다. 다른 모델의 기존 가격표는 수정하지 않았다.

## 검증 결과

- 기존 전체 회귀 테스트: 통과.
- 새 3.8 검증: 소스와 압축된 배포 파일을 각각 실행하여 총 **16개 테스트 그룹 통과**.
- 검사 범위: 모델/설정 보존, 모든 기능의 요청 옵션, 지원 추론값 및 구형 값 변환, 텍스트·JSON 응답, 생각 텍스트 제외, 캐시·추론 비용, 2027년 가격 전환, 기존 비용 보존, 추정 사용량, 타 제공자 요금 미상 처리.
- 요청/오류 검사: Developer API 주소·본문, Vertex 모의 인증·global 주소, Firebase 모의 SDK 구성·응답·모델 미지원 오류, 빈 입력, 400/403/404/429/503, 재시도, 빈 응답의 종료 및 차단 사유.
- 기능 검사: 실제 후보 재정렬 함수가 생성한 프롬프트와 점수 JSON 처리, API 설정 화면의 네 모델 선택기·여덟 추론 설정·모델 변경·연결 테스트 버튼을 모의 환경에서 실행.
- 백업 검사: 현재 데이터 유지, 없는 채팅만 추가, 백업으로 교체 동작과 기존 기본값 확인.
- JavaScript 문법 및 배포 검증: 통과. 38개 모듈, **838,360바이트**, 기존 840,000바이트 제한 이내.
- 기존 저장 키, 메뉴, 외부 라이브러리 버전, 원격 자동 업데이트 차단 설정 보존 확인.

테스트 재실행은 새 소스 폴더에서 `node tests/run-regressions.js`, `node tests/run-gemini38-regressions.js`를 사용한다. 새 테스트의 구문 분석기는 복사된 기존 빌드 의존성의 Acorn을 사용하며, 새 라이브러리 설치나 버전 변경은 하지 않았다.

## 실제 환경에서 확인하지 못한 부분

**실제 유료 API 호출과 실제 사이트에서의 사용자 스크립트 설치·실행은 하지 않았다.** 사용자 키나 채팅 데이터를 테스트에 사용하지 않았다. 인증, 계정별 모델 접근 권한, 할당량, 실제 모델 출력 품질, 사이트/브라우저 환경은 모의 테스트만으로 보장할 수 없다.

Firebase SDK 12.8.0의 추론 수준 지원은 [공식 릴리스 기록](https://firebase.google.com/support/release-notes/js)과 [현재 사용하는 공식 SDK 코드](https://www.gstatic.com/firebasejs/12.8.0/firebase-ai.js)에서 확인했다. 다만 확인 시점의 [Firebase 모델 목록](https://firebase.google.com/docs/ai-logic/models)에는 3.8이 명시되어 있지 않았다. 따라서 **Firebase 요청 형식은 검증했지만, Firebase 서비스가 실제로 3.8을 제공하는지는 미확인**이다. 기존 호출 방식을 다른 서비스로 자동 전환하지 않는다.

## 설치 후 확인

1. 기존 버전은 삭제하지 말고 비활성화한 뒤 새 설치 파일을 추가한다. 동시에 두 버전을 켜지 않는다.
2. 사용 중인 채팅 페이지를 새로고침한다.
3. API 설정 → 연결 및 모델에서 원하는 기능에 **3.8 Flash**를 선택한다. 기존 기본 모델은 자동 변경되지 않는다.
4. **생성 API 테스트**로 계정의 실제 모델 접근 여부를 확인한다. 이 버튼은 실제 요청이므로 요금이 발생할 수 있다.
5. 짧은 대화로 실제 추출/변환 기능을 확인한다. Firebase에서 모델 미지원 오류가 나면 해당 서비스의 제공 상태를 먼저 확인한다.

## 파일 무결성

SHA-256:

- 새 설치 파일: `C423F2BF376CC0D648B54A84A7B1C259B7E1AB062A09D68EFC9F375206828764`
- 원본: `49D242C32E5B4C2623FA304FBC48237A75E240B164DF1B8892753105CD817DC5`
- 이전 3.6/3.7 파일: `5DB1E93DA217EA8DE8C3314921D6D5239E3AD4DB72CA23A710894D466ED06D2A`
