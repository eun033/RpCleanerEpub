'use strict';

// No live requests or user credentials: transports, DOM, Firebase and OAuth are mocked.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const acorn = require('../.build-deps/node_modules/acorn');
const { loadKernel } = require('./run-regressions');
const root = path.resolve(__dirname, '..');
const model = 'gemini-3.8-flash';
const read = rel => fs.readFileSync(path.join(root, rel), 'utf8');
const plain = obj => JSON.parse(JSON.stringify(obj));
const at = Date.UTC(2026, 8, 3);
class FixedDate extends Date { static now() { return at; } }
const success = {
  candidates: [{ content: { role: 'model', parts: [{ text: 'private reasoning', thought: true }, { text: '{"ok":' }, { text: 'true}' }] }, finishReason: 'STOP' }],
  usageMetadata: { promptTokenCount: 100, candidatesTokenCount: 20, thoughtsTokenCount: 30, cachedContentTokenCount: 40, totalTokenCount: 150 }
};
const baseOpts = { apiType: 'key', key: 'test-only-key', model, maxRetries: 0, retryOnServerError: false, skipGenerationQueue: true };

function nodes(source) {
  const found = [];
  const visit = node => {
    if (!node || typeof node !== 'object') return;
    if (node.type) found.push(node);
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach(visit);
      else if (value && typeof value === 'object') visit(value);
    }
  };
  visit(acorn.parse(source, { ecmaVersion: 'latest', sourceType: 'script' }));
  return found;
}

function functionSource(source, name, optional = false) {
  const all = nodes(source);
  const node = all.find(n => n.type === 'FunctionDeclaration' && n.id?.name === name);
  if (node) return source.slice(node.start, node.end);
  const property = all.find(n => n.type === 'Property' && n.key?.name === name && n.value?.type === 'FunctionExpression');
  if (!property && optional) return ''; // Terser can inline private one-use helpers.
  assert(property, 'missing function: ' + name);
  return 'var ' + name + ' = ' + source.slice(property.value.start, property.value.end) + ';';
}

function bundledModule(bundle, marker, functionName) {
  const choices = nodes(bundle).filter(n => n.type === 'FunctionExpression' && !n.id).filter(n => {
    const body = bundle.slice(n.start, n.end);
    return body.includes(marker) && (body.includes('function ' + functionName + '(') || body.includes(functionName + ':async function(') || body.includes(functionName + ':function('));
  }).sort((a, b) => (a.end - a.start) - (b.end - b.start));
  assert(choices.length, 'bundled module not found: ' + marker);
  return '(' + bundle.slice(choices[0].start, choices[0].end) + ')();';
}

function loadBuilders(context, variant) {
  const source = variant.settings;
  context.C = context.__LoreCore;
  context.settings = { config: {}, save() {} };
  const names = ['resolveConfiguredModel', 'getGenerationFallbackModel', 'isModelCompatibleWithApi', 'featureThinkingKey',
    'thinkingModeForFeature', 'geminiThinkingConfigForModel', 'openAIReasoningForFeature', 'deepSeekReasoningForFeature',
    'getGeminiEmbeddingKey', 'normalizeApiModelDefaults', 'getApiMissingReason', 'buildGenerationApiOpts'];
  vm.runInContext(names.map(name => functionSource(source, name, true)).join('\n'), context);
  for (const name of ['buildGenerationApiOpts', 'normalizeApiModelDefaults', 'getGenerationFallbackModel', 'getApiMissingReason']) assert.strictEqual(typeof context[name], 'function', name);
}

async function runtime(variant, overrides = {}) {
  const { contextOverrides = {}, ...rest } = overrides;
  const r = await loadKernel({ kernelSource: variant.kernel, gmPayloads: [success], ...rest,
    contextOverrides: { Date: FixedDate, ...contextOverrides } });
  vm.runInContext(variant.pricing, r.context, { filename: 'pricing-under-test.js' });
  return r;
}

function checkConfig(body, expectedLevel = 'medium') {
  const g = body.generationConfig;
  assert.strictEqual(g.thinkingConfig.thinkingLevel, expectedLevel);
  assert(!('thinkingBudget' in g.thinkingConfig));
  assert(!('thinking_budget' in g.thinkingConfig));
  for (const field of ['temperature', 'topP', 'topK', 'top_p', 'top_k', 'candidateCount', 'candidate_count', 'frequencyPenalty', 'presencePenalty']) {
    assert(!(field in g), 'unsupported generation field: ' + field);
  }
}

function close(actual, expected) { assert(Math.abs(actual - expected) < 1e-12, `${actual} != ${expected}`); }

async function testThinkingAndSettings(variant) {
  const { C, context } = await runtime(variant);
  const normalize = config => plain(C.normalizeGeminiThinkingConfig(model, config));
  for (const level of ['low', 'medium', 'high']) assert.strictEqual(normalize({ thinkingLevel: level }).thinkingLevel, level);
  for (const level of ['minimal', 'off']) assert.strictEqual(normalize({ thinkingLevel: level }).thinkingLevel, 'low');
  for (const level of ['', 'default', 'invalid']) assert.strictEqual(normalize({ thinkingLevel: level }).thinkingLevel, 'medium');
  assert.deepStrictEqual(normalize(), { thinkingLevel: 'medium' });
  assert.deepStrictEqual(normalize(null), { thinkingLevel: 'medium' });
  assert.deepStrictEqual(normalize({ thinking_level: 'HIGH', thinking_budget: 512, includeThoughts: false }), { thinkingLevel: 'high', includeThoughts: false });
  for (const [budget, level] of [[-1, 'medium'], [0, 'low'], [512, 'low'], [1024, 'low'], [2048, 'medium'], [4096, 'high']]) {
    assert.deepStrictEqual(normalize({ thinkingBudget: budget }), { thinkingLevel: level });
  }
  const original = { thinkingLevel: 'minimal', thinkingBudget: 512 };
  normalize(original);
  assert.deepStrictEqual(original, { thinkingLevel: 'minimal', thinkingBudget: 512 });
  for (const other of ['gemini-3.6-flash', 'gemini-3.7-flash', 'gemini-3-flash-preview', 'gemini-2.5-flash', 'deepseek-v4-flash']) {
    assert.strictEqual(C.normalizeGeminiThinkingConfig(other, original), original);
  }
  loadBuilders(context, variant);
  const features = ['autoExtract', 'batchExtract', 'batchExtractRetry', 'temporalExtract', 'urlImport', 'textImport', 'import', 'rerank', 'judge', 'refine', 'merge'];
  for (const provider of ['key', 'vertex', 'firebase']) {
    context.settings.config = { autoExtApiType: provider, autoExtKey: 'test-only-key', autoExtModel: model,
      rerankModel: model, temporalRecallJudgeModel: model, refinerModel: model, autoExtReasoning: 'minimal', autoExtBudget: 512 };
    const before = plain(context.settings.config);
    context.normalizeApiModelDefaults(context.settings.config);
    assert.deepStrictEqual(plain(context.settings.config), before, 'stored model settings changed');
    for (const feature of features) {
      const opts = context.buildGenerationApiOpts({ model }, { feature, chatKey: 'test-chat' });
      assert.strictEqual(opts.model, model);
      assert.strictEqual(opts.apiType, provider);
      assert.strictEqual(opts.thinkingConfig.thinkingLevel, 'low');
      assert.strictEqual(opts.responseMimeType, 'application/json');
    }
    for (const [reason, budget, level] of [['default', 2048, 'medium'], ['off', 2048, 'low'], ['budget', 512, 'low'], ['budget', 4096, 'high']]) {
      context.settings.config.autoExtReasoning = reason;
      context.settings.config.autoExtBudget = budget;
      const opts = context.buildGenerationApiOpts({ thinkingConfig: { thinkingBudget: 512 } });
      assert.strictEqual(opts.thinkingConfig.thinkingLevel, reason === 'default' ? 'low' : level, 'legacy override conversion');
      assert(!('thinkingBudget' in opts.thinkingConfig));
    }
    context.settings.config.autoExtReasoning = 'default';
    assert.strictEqual(context.buildGenerationApiOpts().thinkingConfig.thinkingLevel, 'medium');
  }
  context.settings.config = { autoExtApiType: 'key', autoExtModel: 'gemini-2.5-flash', autoExtReasoning: 'budget', autoExtBudget: 2048 };
  assert.deepStrictEqual(plain(context.buildGenerationApiOpts().thinkingConfig), { thinkingBudget: 2048 });
  assert.strictEqual(context.getGenerationFallbackModel({}), 'gemini-3-flash-preview');
  context.settings.config = { autoExtApiType: 'openai', autoExtModel: '_custom', autoExtCustomModel: 'google/' + model };
  assert(!context.buildGenerationApiOpts().thinkingConfig);
  assert.strictEqual(context.buildGenerationApiOpts().model, 'google/' + model);
}

async function testRequestsResponsesCosts(variant) {
  const { C, context, requests } = await runtime(variant);
  for (const level of ['low', 'medium', 'high', 'minimal']) {
    const result = await C.callGeminiApi('Return exactly one JSON object: {"ok":true}', { ...baseOpts,
      responseMimeType: 'application/json', maxOutputTokens: 4096,
      thinkingConfig: { thinkingLevel: level, thinkingBudget: 1000 },
      temperature: 1, topP: 0.8, candidateCount: 2,
      costContext: { feature: 'autoExtract', chatKey: 'test-chat' } });
    assert.deepStrictEqual(JSON.parse(result.text), { ok: true });
    assert.strictEqual(result.error, null);
    assert.strictEqual(result.cost.outTok, 50, 'thinking tokens must be billed once');
    assert.strictEqual(result.cost.inTok, 100);
    assert.strictEqual(result.cost.cacheHitTok, 40);
    assert.strictEqual(result.cost.provider, 'key');
    assert.strictEqual(result.cost.estimated, false);
    close(result.cost.usd, (60 * 0.75 + 40 * 0.075 + 50 * 3.75) / 1e6);
    const request = requests.at(-1);
    assert.strictEqual(request.url, 'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent');
    assert.strictEqual(request.headers['x-goog-api-key'], 'test-only-key');
    const body = JSON.parse(request.data);
    assert.deepStrictEqual(body.contents, [{ role: 'user', parts: [{ text: 'Return exactly one JSON object: {"ok":true}' }] }]);
    checkConfig(body, level === 'minimal' ? 'low' : level);
    assert.strictEqual(body.generationConfig.responseMimeType, 'application/json');
    assert.strictEqual(body.generationConfig.maxOutputTokens, 4096);
  }
  loadBuilders(context, variant);
  context.settings.config = { autoExtApiType: 'key', autoExtKey: 'test-only-key', autoExtModel: model, autoExtReasoning: 'medium' };
  for (const feature of ['autoExtract', 'batchExtract', 'temporalExtract', 'textImport', 'rerank', 'judge', 'refine', 'merge']) {
    const opts = context.buildGenerationApiOpts({ ...baseOpts, model }, { feature, chatKey: 'test-chat' });
    const result = await C.callGeminiApi('대화: 사용자: 안녕하세요. AI: 반갑습니다. JSON으로 분석해 주세요.', opts);
    assert(result.text);
    assert.strictEqual(result.cost.feature, feature);
    checkConfig(JSON.parse(requests.at(-1).data));
  }
  const count = requests.length;
  for (const empty of ['', ' \n ', null, []]) {
    const result = await C.callGeminiApi(empty, baseOpts);
    assert.match(result.error, /비어 있지 않은 텍스트/);
    assert.strictEqual(result.status, 0);
  }
  assert.strictEqual(requests.length, count, 'empty prompts must not make a request');
  close(C.computeCost(model, 1e6, 1e6, 1e6, Date.UTC(2026, 11, 31, 23, 59, 59)), 4.5);
  close(C.computeCost(model, 1e6, 1e6, 1e6, Date.UTC(2027, 0, 1)), 9);
  close(C.computeCostDetailed(model, 1e6, 1e6, { ts: Date.UTC(2027, 0, 1), cacheHitTok: 1e6, provider: 'vertex' }), 7.65);
  assert.strictEqual(C.computeCostDetailed(model, 10, 10, { provider: 'openai' }), null);
  assert.strictEqual(C.computeCost(model + '-unknown', 10, 10), null);
  close(C.computeCost('gemini-2.5-flash', 1e6, 1e6), 2.8);
  const oldEvents = C.getCostEvents();
  vm.runInContext('Date.now = () => Date.UTC(2027, 0, 2);', context);
  assert.deepStrictEqual(plain(C.getCostEvents()), plain(oldEvents), 'historical costs changed');
  FixedDate.now = () => at;
  const estimated = await runtime(variant, { gmPayloads: [{ candidates: success.candidates }] });
  const estimatedResult = await estimated.C.callGeminiApi('abcd', baseOpts);
  assert.strictEqual(estimatedResult.cost.estimated, true);
  assert.strictEqual(estimatedResult.cost.inTok, 1);
  const proxy = await runtime(variant, { gmPayloads: [{ choices: [{ message: { content: 'ok' } }], usage: { prompt_tokens: 10, completion_tokens: 2 } }] });
  const proxyResult = await proxy.C.callGeminiApi('test', { ...baseOpts, apiType: 'openai', openAIBaseUrl: 'https://provider.test/v1/chat/completions', openAIKey: 'mock', openAIFormat: 'custom' });
  assert.strictEqual(proxyResult.text, 'ok');
  assert.strictEqual(proxyResult.cost.usd, null);
  assert.strictEqual(proxyResult.cost.unknown, true);
}

async function testErrors(variant) {
  for (const status of [400, 403, 404, 429, 503]) {
    const r = await runtime(variant, { gmStatuses: [status] });
    const result = await r.C.callGeminiApi('test', baseOpts);
    assert.strictEqual(result.status, status);
    assert.match(result.error, new RegExp('HTTP ' + status));
    assert.strictEqual(r.requests.length, 1);
  }
  for (const payload of [
    { candidates: [{ finishReason: 'MAX_TOKENS' }] },
    { candidates: [{ finishReason: 'SAFETY', finishMessage: 'blocked' }] },
    { promptFeedback: { blockReason: 'PROHIBITED_CONTENT' } },
    { candidates: [{ content: { parts: [{ text: 'reasoning only', thought: true }] }, finishReason: 'STOP' }] }
  ]) {
    const r = await runtime(variant, { gmPayloads: [payload] });
    const result = await r.C.callGeminiApi('test', baseOpts);
    assert.strictEqual(result.text, null);
    assert.match(result.error, /MAX_TOKENS|SAFETY|PROHIBITED_CONTENT|STOP/);
  }
  const r = await runtime(variant, { gmStatuses: [429, 200],
    contextOverrides: { setTimeout: (fn, ms, ...args) => setTimeout(fn, Math.min(ms, 2), ...args) } });
  const result = await r.C.callGeminiApi('retry test', { ...baseOpts, maxRetries: 1 });
  assert.strictEqual(result.text, '{"ok":true}');
  assert.strictEqual(r.requests.length, 2);
}

async function testRealFeatureRequest(variant) {
  const payload = { ...success, candidates: [{ content: { parts: [{ text: '{"scores":[5,1]}' }] }, finishReason: 'STOP' }] };
  const { C, context, requests } = await runtime(variant, { gmPayloads: [payload] });
  context.callGeminiApi = C.callGeminiApi;
  context.DEFAULTS = C.DEFAULTS;
  vm.runInContext(functionSource(variant.search, 'smartRerank'), context);
  const entries = [{ entry: { name: '민수', type: 'character', summary: '민수는 서울에서 일한다.' }, score: 0.8 },
    { entry: { name: '다른 장면', type: 'event', summary: '관련 없는 이야기.' }, score: 0.4 }];
  const result = await context.smartRerank('민수는 어디서 일하나요?', entries, [{ role: 'user', message: '민수에 대해 알려줘.' }],
    { ...baseOpts, thinkingConfig: { thinkingLevel: 'minimal' }, costContext: { feature: 'rerank', chatKey: 'test-chat' } }, {});
  assert.strictEqual(result.length, 1);
  assert.strictEqual(result[0].entry.name, '민수');
  assert.strictEqual(result[0].llmScore, 5);
  const body = JSON.parse(requests[0].data);
  assert(body.contents[0].parts[0].text.includes('민수는 어디서 일하나요?'));
  assert(body.contents[0].parts[0].text.includes('민수는 서울에서 일한다.'));
  assert.strictEqual(body.generationConfig.responseMimeType, 'application/json');
  checkConfig(body, 'low');
}

async function testVertex(variant) {
  const token = { access_token: 'mock-token' };
  const r = await runtime(variant, { gmPayloads: [token, success], contextOverrides: {
    ArrayBuffer, Uint8Array,
    atob: value => Buffer.from(value, 'base64').toString('binary'),
    btoa: value => Buffer.from(value, 'binary').toString('base64'),
    crypto: { subtle: { importKey: async () => ({}), sign: async () => new Uint8Array([1, 2, 3]).buffer } }
  } });
  const result = await r.C.callGeminiApi('vertex test', { ...baseOpts, apiType: 'vertex', vertexLocation: 'us-central1',
    vertexJson: JSON.stringify({ project_id: 'test-project', client_email: 'test@example.invalid', private_key: '-----BEGIN PRIVATE KEY-----\nAA==\n-----END PRIVATE KEY-----' }) });
  assert.strictEqual(result.error, null);
  assert.strictEqual(result.cost.provider, 'vertex');
  assert.strictEqual(r.requests[0].url, 'https://oauth2.googleapis.com/token');
  assert.strictEqual(r.requests[1].url, 'https://aiplatform.googleapis.com/v1/projects/test-project/locations/global/publishers/google/models/' + model + ':generateContent');
  assert.strictEqual(r.requests[1].headers.Authorization, 'Bearer mock-token');
  checkConfig(JSON.parse(r.requests[1].data));
  assert.strictEqual(r.C.resolveVertexEndpoint('us-central1', 'gemini-2.5-flash').location, 'us-central1');
}

async function testFirebase(variant) {
  const calls = [];
  let response = success;
  let failure = null;
  const sdk = {
    initializeApp: (cfg, name) => ({ cfg, name }),
    VertexAIBackend: class { constructor(location) { this.location = location; } },
    getAI: (app, options) => { calls.push({ app, options }); return options; },
    getGenerativeModel: (ai, options) => {
      calls.push({ model: options });
      return { generateContent: async prompt => { calls.push({ prompt }); if (failure) throw failure; return { response }; } };
    },
    HarmCategory: {}, HarmBlockThreshold: { OFF: 'OFF' }
  };
  const r = await runtime(variant, { contextOverrides: { __crackExtFirebaseSdk: sdk } });
  const opts = { ...baseOpts, apiType: 'firebase', firebaseScript: '{"apiKey":"mock","projectId":"test"}', thinkingConfig: { thinkingLevel: 'minimal', thinkingBudget: 512 }, responseMimeType: 'application/json' };
  assert(await r.C.warmupFirebase(opts.firebaseScript, model));
  const result = await r.C.callGeminiApi('firebase test', opts);
  assert.strictEqual(result.text, '{"ok":true}');
  assert.strictEqual(result.cost.provider, 'firebase');
  assert.strictEqual(result.cost.outTok, 50);
  assert.strictEqual(calls.find(c => c.options).options.backend.location, 'global');
  const modelCall = calls.find(c => c.model).model;
  assert.strictEqual(modelCall.model, model);
  checkConfig(modelCall, 'LOW');
  assert.strictEqual(modelCall.generationConfig.responseMimeType, 'application/json');
  assert.strictEqual(r.requests.length, 0, 'Firebase SDK must not fall through to old REST branch');
  response = { candidates: [{ finishReason: 'SAFETY' }] };
  assert.match((await r.C.callGeminiApi('blocked', opts)).error, /SAFETY/);
  failure = new Error('404 model not found');
  assert.match((await r.C.callGeminiApi('unavailable', opts)).error, /Firebase: 404 model not found/);
}

class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.style = {}; this.value = ''; this.textContent = ''; }
  appendChild(child) { child.parent = this; this.children.push(child); return child; }
  remove() { this.parent.children = this.parent.children.filter(c => c !== this); }
  addEventListener(name, fn) { this['on' + name] = fn; }
}
function descendants(node) { return [node, ...node.children.flatMap(descendants)]; }

async function testUi(variant) {
  const { C, context } = await runtime(variant);
  loadBuilders(context, variant);
  context.document = { createElement: tag => new Element(tag) };
  context.settings.config = { autoExtApiType: 'key', autoExtModel: model, autoExtReasoning: 'minimal', autoExtKey: 'mock',
    rerankModel: model, temporalRecallJudgeModel: model, refinerModel: model };
  C.setFullWidth = () => {};
  C.createApiInput = () => {};
  let registered;
  context.__LoreInj = { __settingsLoaded: true, C, settings: context.settings,
    buildGenerationApiOpts: context.buildGenerationApiOpts, getGenerationFallbackModel: context.getGenerationFallbackModel,
    normalizeApiModelDefaults: context.normalizeApiModelDefaults, getApiMissingReason: context.getApiMissingReason,
    registerSubMenu: (key, fn) => { if (key === 'api') registered = fn; } };
  await vm.runInContext(variant.ui, context);
  let entry;
  registered({ createSubMenu(name, fn) { if (name === 'API 설정') entry = fn; } });
  const rootElement = new Element('root');
  entry({ replaceContentPanel(fn) { fn({ addBoxedField(a, b, options) { options.onInit(rootElement); } }); } });
  const modelSelects = () => descendants(rootElement).filter(el => el.tagName === 'select' && el.children.some(child => child.tagName === 'optgroup'));
  assert.strictEqual(modelSelects().length, 4);
  for (const select of modelSelects()) {
    const values = descendants(select).filter(el => el.tagName === 'option').map(el => el.value);
    for (const id of [model, 'gemini-3.6-flash', 'gemini-3.7-flash']) assert(values.includes(id));
  }
  const reasoningSelects = () => descendants(rootElement).find(el => el.tagName === 'details').children.flatMap(descendants).filter(el => el.tagName === 'select');
  assert.strictEqual(reasoningSelects().length, 8);
  for (const select of reasoningSelects()) {
    assert.deepStrictEqual(select.children.map(el => el.value), ['default', 'low', 'medium', 'high']);
  }
  assert.strictEqual(reasoningSelects()[0].value, 'low');
  assert.strictEqual(context.settings.config.autoExtReasoning, 'minimal', 'rendering must not rewrite saved reasoning');
  const first = modelSelects()[0];
  first.value = 'gemini-3.6-flash'; first.onchange();
  assert(reasoningSelects()[0].children.some(el => el.value === 'minimal'), 'other-model options not restored');
  first.value = model; first.onchange();
  assert(!reasoningSelects()[0].children.some(el => el.value === 'minimal'), 'model change did not refresh options');
  reasoningSelects()[0].value = 'high'; reasoningSelects()[0].onchange();
  assert.strictEqual(context.settings.config.autoExtReasoning, 'high');
  let captured;
  C.callGeminiApi = async (prompt, opts) => { captured = { prompt, opts }; return { text: '{"ok":true}' }; };
  const testButton = descendants(rootElement).find(el => el.textContent === '생성 API 테스트');
  await testButton.onclick();
  assert.strictEqual(captured.opts.model, model);
  assert.strictEqual(captured.opts.thinkingConfig.thinkingLevel, 'high');
  assert.strictEqual(captured.opts.responseMimeType, 'application/json');
}

async function testBackupAndFallback(variant) {
  const { C, context } = await runtime(variant);
  context.C = C;
  context.settings = { config: { autoExtApiType: 'key', autoExtModel: model, autoExtReasoning: 'minimal' } };
  context._w = { __LoreInj: {} };
  vm.runInContext(functionSource(variant.fallback, 'buildGenerationApiOpts'), context);
  assert.strictEqual(context.buildGenerationApiOpts().thinkingConfig.thinkingLevel, 'low');
  context.settings.config.autoExtReasoning = 'off';
  assert.strictEqual(context.buildGenerationApiOpts().thinkingConfig.thinkingLevel, 'low');
  context.clonePlain = plain;
  vm.runInContext(functionSource(variant.backup, 'mergeObjectMap'), context);
  const current = { same: 'keep', present: 'present' }, incoming = { same: 'replace', missing: 'new' };
  assert.deepStrictEqual(plain(context.mergeObjectMap(current, incoming, 'current')), current);
  assert.deepStrictEqual(plain(context.mergeObjectMap(current, incoming, 'add_missing')), { ...current, missing: 'new' });
  assert.deepStrictEqual(plain(context.mergeObjectMap(current, incoming, 'backup')), incoming);
}

async function main() {
  const bundle = read('universal_bundle_work/dist/erie_crack_inject_universal_gemini38_backup_choice.user.js');
  const variants = [
    { name: 'source', kernel: read('embedding/core-kernel.js'), pricing: read('embedding/core-pricing.js'), ui: read('embedding/injecter-6-sub-api.js'),
      settings: read('embedding/injecter-3.js'), search: read('embedding/core-search.js'), fallback: read('embedding/injecter-6-sub-extract.js'), backup: read('embedding/injecter-6-sub-file.js') },
    { name: 'built userscript', kernel: bundledModule(bundle, '__kernelLoaded', 'callGeminiApi'),
      pricing: bundledModule(bundle, '__pricingLoaded', 'computeCost'), ui: bundledModule(bundle, '__subApiLoaded', 'addSelect'),
      settings: bundledModule(bundle, '__settingsLoaded', 'getGenerationFallbackModel'), search: bundledModule(bundle, '__searchLoaded', 'smartRerank'),
      fallback: bundledModule(bundle, '__subExtractLoaded', 'buildGenerationApiOpts'), backup: bundledModule(bundle, '__subFileLoaded', 'mergeObjectMap') }
  ];
  for (const variant of variants) {
    for (const test of [testThinkingAndSettings, testRequestsResponsesCosts, testErrors, testRealFeatureRequest, testVertex, testFirebase, testUi, testBackupAndFallback]) {
      await test(variant);
      process.stdout.write('PASS ' + variant.name + ': ' + test.name + '\n');
    }
  }
  process.stdout.write('Gemini 3.8 regressions passed: 16 groups; source and built userscript; no live API calls.\n');
}
main().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
