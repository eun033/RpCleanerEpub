// refiner / observer 모듈
// 역할: 메시지 감지 — MutationObserver + 폴링, idle 감지, 큐 enqueue
// 의존: queue, Core
(function () {
  'use strict';
  const _w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
  const R = _w.__LoreRefiner = _w.__LoreRefiner || {};
  if (!R.__queueLoaded) { console.error('[Refiner:observer] queue 미로드'); try { _w.__LoreInj?.markFailed?.('refinerObserver', 'queue missing'); } catch (_) {} return; }
  if (R.__observerLoaded) return;

  let lastAssistantMsgId = null;
  let lastMsgLength = 0;
  let idleCount = 0;
  let lastChangeTime = 0;
  let _needsWarmup = true;
  let _lastKnownUrl = '';
  let _chatObserver = null;
  let _pollingInterval = null;
  // v1.4.0-test.38 B2 fix: 워치독 핸들 보관 — SPA 라우트 전환 시 setupObserver 재호출되며 누적 방지
  let _watchdogInterval = null;
  let _waitingSince = 0;

  function setRefinerState(state, detail) {
    R.lastState = { state: state || 'idle', detail: detail || '', at: Date.now(), queue: R.refineQueue ? R.refineQueue.length : 0, busy: !!R.workerBusy };
  }

  function isChatPath() {
    const fn = _w.__LoreInj && _w.__LoreInj.isChatPath;
    if (typeof fn === 'function') {
      try { return !!fn(); } catch (_) {}
    }
    return /\/characters\/[a-f0-9]+\/chats\/[a-f0-9]+/.test(location.pathname)
      || /\/stories\/[a-f0-9]+\/episodes\/[a-f0-9]+/.test(location.pathname)
      || /\/u\/[a-f0-9]+\/c\/[a-f0-9]+/.test(location.pathname);
  }

  async function checkLatestMessage() {
    const config = R.ConfigGetter();
    if (!config.refinerEnabled) { R.Core && R.Core.hideStatusBadge(); setRefinerState('off', '꺼짐'); return; }

    const currentUrl = R.Core.getCurUrl();
    if (currentUrl !== _lastKnownUrl) {
      _lastKnownUrl = currentUrl; lastAssistantMsgId = null; lastMsgLength = 0; idleCount = 0; _needsWarmup = true;
    }

    const chatId = R.Core.getCurrentChatId();
    if (!chatId) { R.Core && R.Core.hideStatusBadge(); setRefinerState('idle', '채팅방 대기'); return; }

    try {
      const lastLog = await CrackUtil.chatRoom().findLastMessageId(chatId, "assistant");
      if (!lastLog || lastLog instanceof Error) return;

      const msgId = lastLog.id || (lastLog.content ? lastLog.content.slice(0, 40) : '');
      const contentLen = lastLog.content ? lastLog.content.length : 0;
      if (R.rememberAssistantMessage && lastLog.content) R.rememberAssistantMessage(msgId, lastLog.content);

      if (_needsWarmup) {
        lastAssistantMsgId = msgId; lastMsgLength = contentLen; idleCount = 0; lastChangeTime = Date.now(); _needsWarmup = false;
        if (msgId) { R.getProcessedFingerprints().add(msgId); R.saveProcessedFingerprints(); }
        return;
      }

      if (msgId !== lastAssistantMsgId) {
        R.Core.showStatusBadge('에리가 응답 기다리는 중');
        _waitingSince = Date.now();
        setRefinerState('waiting', '응답 작성 확인 중');
        lastAssistantMsgId = msgId; lastMsgLength = contentLen; idleCount = 0; lastChangeTime = Date.now();
      } else {
        if (contentLen === lastMsgLength && lastMsgLength > 0) {
          idleCount++;
          if (idleCount >= 2 && Date.now() - lastChangeTime > 4000) {
            setRefinerState('queued', '응답 작성 완료');
            _waitingSince = 0;
            R.enqueueRefine(lastLog.content, msgId);
          }
        } else {
          lastMsgLength = contentLen; idleCount = 0; lastChangeTime = Date.now();
          setRefinerState('waiting', '응답 작성 중');
        }
      }
    } catch (e) {}
  }

  function setupObserver() {
    if (_chatObserver) _chatObserver.disconnect();
    if (_pollingInterval) clearInterval(_pollingInterval);
    if (_watchdogInterval) clearInterval(_watchdogInterval);

    if (!isChatPath()) {
      console.log('[Refiner:observer] non-chat route: observer skipped');
      R.Core && R.Core.hideStatusBadge();
      setRefinerState('idle', '채팅 화면 대기');
      return;
    }

    _chatObserver = new MutationObserver(() => {
      const config = R.ConfigGetter();
      if (!config.refinerEnabled) { R.Core && R.Core.hideStatusBadge(); setRefinerState('off', '꺼짐'); return; }
      if (window._refinerDebounceTimer) clearTimeout(window._refinerDebounceTimer);
      window._refinerDebounceTimer = setTimeout(() => { checkLatestMessage(); }, 800);
    });
    _chatObserver.observe(document.body, { childList: true, subtree: true, characterData: true });

    _pollingInterval = setInterval(() => {
      const config = R.ConfigGetter();
      if (config.refinerEnabled) checkLatestMessage();
    }, 3000);

    // v1.4.0-test.38 B1+B2 fix: R.workerBusy/R.workerStartTime은 이제 refiner-queue가 노출함. 핸들 저장으로 누수 방지.
    _watchdogInterval = setInterval(() => {
      if (R.workerBusy && Date.now() - R.workerStartTime > R.WORKER_TIMEOUT) {
        R.workerBusy = false; R.Core && R.Core.hideStatusBadge();
        setRefinerState('timeout', '교정 처리 시간 초과');
      }
      if (_waitingSince && Date.now() - _waitingSince > 45000) {
        _waitingSince = 0;
        R.Core && R.Core.hideStatusBadge();
        setRefinerState('timeout', '응답 대기 시간 초과');
      }
      if (R.refineQueue.length > 0 && !R.workerBusy) R.processQueue();
    }, 2000);
  }

  R.setupObserver = setupObserver;
  R.setNeedsWarmup = function() { _needsWarmup = true; };
  R.getRefinerState = function() { return R.lastState || { state: 'idle', detail: '', at: 0, queue: R.refineQueue ? R.refineQueue.length : 0, busy: !!R.workerBusy }; };
  R.__observerLoaded = true;

})();
