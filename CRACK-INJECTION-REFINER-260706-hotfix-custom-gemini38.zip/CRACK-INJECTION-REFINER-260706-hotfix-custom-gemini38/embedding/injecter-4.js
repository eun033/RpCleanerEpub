// == 인젝터 모듈 4/6 — 추출 파이프라인 ==
// mergeExtractedData, runAutoExtract, _doExtract, extBadge watchdog
(async function(){
  'use strict';
  if(document.readyState === 'loading') await new Promise(r => document.addEventListener('DOMContentLoaded', r));
  const _w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

  const deadline = Date.now() + 15000;
  while (!(_w.__LoreInj && _w.__LoreInj.__settingsLoaded) && Date.now() < deadline) await new Promise(r => setTimeout(r, 50));
  if (!(_w.__LoreInj && _w.__LoreInj.__settingsLoaded)) { console.error('[LoreInj:4] settings 미로드'); return; }
  if (_w.__LoreInj.__extractLoaded) return;

  const {
    C, db, _ls, settings,
    parseJsonLoose, createSnapshot,
    getChatKey, getTurnCounter,
    getAutoExtPackForUrl,
    addExtLog, setPackEnabled,
    DEFAULT_AUTO_EXTRACT_SCHEMA,
    DEFAULT_AUTO_EXTRACT_PATCH_SCHEMA,
    DEFAULT_TEMPORAL_EXTRACT_PROMPT,
    DEFAULT_TEMPORAL_EXTRACT_SCHEMA
  } = _w.__LoreInj;

  // v1.4.0-test.56: patch ON/OFF must not change the DB context payload. Only output instructions differ.
  const OUTPUT_MODE_PATCH = `OUTPUT MODE: SAVE ONLY CHANGES
- Existing entries are provided as compact digests with stable "id".
- Output must be one JSON array. Never return a bare object.
- For an existing entry, do NOT re-output the full object.
- Output {"op":"patch","id":...} only when something changed.
- For unchanged existing entries, output nothing.
- If nothing changed at all, return exactly [].
- For brand-new lore, output {"op":"add","entry":{...}}.
- Do not repeat unchanged summary.full.
- Prefer set.state only if state changed.
- Prefer append.eventHistory for new concrete events.
- Prefer append.triggers for new literal aliases.
- If summary.full is unavoidable, keep it under 220 chars.
- Anchored entries: only append new triggers/eventHistory/callHistory.`;

  const OUTPUT_MODE_FULL = `OUTPUT MODE: FULL UPDATED ENTRIES
- Existing entries are provided as compact digests with stable "id".
- Output must be one JSON array. Never return a bare object.
- For each NEW lore, output the complete entry object.
- For each UPDATED existing entry, output the complete updated entry object and keep the same "name" when possible.
- Do NOT use add/patch op format in this mode.
- For unchanged existing entries, output nothing.
- Anchored entries: only append new triggers and eventHistory.`;

  function buildExtractSchema(tpl) {
    const baseSchema = (tpl && tpl.schema) || DEFAULT_AUTO_EXTRACT_SCHEMA;
    return `${baseSchema}

Optional important-line entry when the selected scope includes it:
{
  "type": "key_quote",
  "name": "Stable short recall handle",
  "speaker": "Exact speaker name",
  "quote": "Exact or minimally normalized source line",
  "context": "who, where, and what prompted the line",
  "meaning": "why the line may be recalled or quoted later",
  "recallTriggers": ["speaker", "distinctive literal phrase"],
  "linkedLore": ["related character, relationship, promise, or event"],
  "triggers": ["literal high-specificity cue"],
  "summary": {"full":"line + context + later significance", "compact":"line + significance", "micro":"speaker: recall handle"},
  "imp": 7, "sur": 5, "emo": 7
}

Patch-mode alternative when OUTPUT MODE asks for SAVE ONLY CHANGES:
${DEFAULT_AUTO_EXTRACT_PATCH_SCHEMA || '[]'}`;
  }

  const DEFAULT_EXTRACT_TOPICS = {
    identityState: true,
    relationships: true,
    obligations: true,
    worldContinuity: true,
    majorScenes: true,
    importantLines: true
  };

  function normalizeExtractTopics(raw) {
    const source = raw && typeof raw === 'object' ? raw : {};
    const out = {};
    for (const key of Object.keys(DEFAULT_EXTRACT_TOPICS)) out[key] = source[key] !== false;
    return out;
  }

  function buildExtractionScope(topics) {
    const t = normalizeExtractTopics(topics);
    const rows = [
      ['identityState', 'IDENTITY AND CURRENT STATE: identities, aliases, roles, goals, knowledge, secrets, injuries, conditions, and current situation.'],
      ['relationships', 'RELATIONSHIPS: dynamics, boundaries, forms of address, private/public state, and meaningful changes.'],
      ['obligations', 'OBLIGATIONS: promises, contracts, debts, duties, conditions, and lifecycle changes.'],
      ['worldContinuity', 'WORLD CONTINUITY: locations, factions, items, ownership, abilities, costs, limits, systems, and setting rules.'],
      ['majorScenes', 'MAJOR SCENES: reveals, decisions, conflicts, milestones, victories, losses, consequences, and unresolved hooks.'],
      ['importantLines', 'IMPORTANT LINES: type="key_quote" only for a distinctive source line likely to be deliberately recalled, mirrored, or quoted later because it carries a reveal, decision, promise, threat, confession, boundary, or recurring motif. Do not force a quote and do not paraphrase ordinary dialogue into one.']
    ];
    const enabled = rows.filter(([key]) => t[key]).map(([, text]) => '- ' + text);
    const disabled = rows.filter(([key]) => !t[key]).map(([, text]) => '- Do not extract ' + text.split(':')[0].toLowerCase() + ' in this run.');
    return `\n\nEXTRACTION SCOPE FOR THIS RUN:\n${enabled.length ? enabled.join('\n') : '- No general category selected. Return the required empty JSON shape.'}${disabled.length ? '\n' + disabled.join('\n') : ''}`;
  }

  const TEMPORAL_OUTPUT_MODE_PATCH = `OUTPUT MODE: SAVE ONLY CHANGES
- Existing important scene memories are provided as compact digests with stable "id".
- Output must be one JSON array. Never return a bare object.
- For an existing scene memory, do NOT re-output the full object.
- Output {"op":"patch","id":...} only when something changed.
- For unchanged existing scene memories, output nothing.
- If nothing changed at all, return exactly [].
- For brand-new important scenes, output {"op":"add","entry":{...}}.
- If the conversation only repeats already stored scene memories, output [].
- Keep patch fields tiny: prefer append.hooks, append.recallTriggers, append.actions, or set.summary.compact/micro only when changed.`;

  const TEMPORAL_OUTPUT_MODE_FULL = `OUTPUT MODE: FULL UPDATED SCENE MEMORIES
- Existing important scene memories are provided as compact digests with stable "id".
- Output must be one JSON array. Never return a bare object.
- For each NEW important scene, output the complete timeline_event object.
- For each UPDATED existing scene, output the complete updated timeline_event object and keep the same "name" when possible.
- Do NOT use add/patch op format in this mode.
- For unchanged existing scene memories, output nothing.
- If the conversation only repeats already stored scene memories, output [].`;

  const TEMPORAL_PATCH_SCHEMA = `[
  {
    "op": "add",
    "entry": {
      "type": "timeline_event",
      "title": "Short event title",
      "name": "Stable recall handle",
      "when": {"turnStart": 0, "turnEnd": 0, "relative": "past|current|foreshadow", "anchor": "scene/time anchor", "confidence": 0.8},
      "participants": [],
      "location": "",
      "actions": [],
      "summary": {"full": "self-contained event memory", "compact": "event + consequence + hook", "micro": "handle=current meaning"},
      "hooks": [],
      "linkedLore": [],
      "recallTriggers": [],
      "importance": 8,
      "emotional": 8,
      "confidence": 0.8
    }
  },
  {
    "op": "patch",
    "id": 0,
    "reason": "short reason",
    "set": {
      "title": "",
      "name": "",
      "when": {},
      "location": "",
      "summary": {"compact": "", "micro": ""}
    },
    "append": {
      "participants": [],
      "actions": [],
      "hooks": [],
      "linkedLore": [],
      "recallTriggers": []
    }
  }
]`;

  function deepSeekObjectOutputMode(text, emptyObject) {
    return String(text || '')
      .replace(/Output must be one JSON array\. Never return a bare object\./g, 'Output must be one JSON object. Never return a bare array.')
      .replace(/If nothing changed at all, return exactly \[\]\./g, 'If nothing changed at all, return exactly ' + emptyObject + '.')
      .replace(/If the conversation only repeats already stored scene memories, output \[\]\./g, 'If the conversation only repeats already stored scene memories, return exactly ' + emptyObject + '.')
      .replace(/For unchanged existing entries, output nothing\./g, 'For unchanged existing entries, add nothing to entries.')
      .replace(/For unchanged existing scene memories, output nothing\./g, 'For unchanged existing scene memories, add nothing to entries.')
      .replace(/For each NEW lore, output the complete entry object\./g, 'For each NEW lore, put the complete entry object inside entries.')
      .replace(/For each UPDATED existing entry, output the complete updated entry object/g, 'For each UPDATED existing entry, put the complete updated entry object inside entries')
      .replace(/For each NEW important scene, output the complete timeline_event object\./g, 'For each NEW important scene, put the complete timeline_event object inside entries.')
      .replace(/For each UPDATED existing scene, output the complete updated timeline_event object/g, 'For each UPDATED existing scene, put the complete updated timeline_event object inside entries');
  }

  function providerOutputMode(baseText, apiOpts, kind) {
    if (!(apiOpts && apiOpts.apiType === 'deepseek')) return baseText;
    return deepSeekObjectOutputMode(baseText, '{"entries":[]}') + '\n- Top-level object shape must be exactly {"entries":[...]}.';
  }

  function normalizeEntryForMerge(entry, turn) {
    if (C.normalizeLoreEntry) return C.normalizeLoreEntry(entry, { turn, source: 'auto_extracted' });
    return entry;
  }

  function mergeArrayUnique(a, b) {
    return Array.from(new Set([...(Array.isArray(a) ? a : []), ...(Array.isArray(b) ? b : [])].filter(Boolean)));
  }

  function mergeCallState(existing, incoming) {
    if (!incoming || typeof incoming !== 'object') return existing;
    const base = existing && typeof existing === 'object' ? JSON.parse(JSON.stringify(existing)) : {};
    for (const [k, v] of Object.entries(incoming)) {
      if (!base[k]) base[k] = v;
      else if (typeof base[k] === 'object' && typeof v === 'object') base[k] = { ...base[k], ...v };
      else base[k] = v;
    }
    return base;
  }

  function mergeInject(existing, incoming, name, state) {
    if (!incoming || typeof incoming !== 'object') return existing;
    const base = existing && typeof existing === 'object' ? JSON.parse(JSON.stringify(existing)) : {};
    const merged = C.mergeLoreSummary ? C.mergeLoreSummary(base, incoming, name, state) : null;
    return {
      full: merged ? merged.full : (incoming.full || base.full || ''),
      compact: merged ? merged.compact : (incoming.compact || base.compact || ''),
      micro: incoming.micro || base.micro || ''
    };
  }

  function selectExistingForContext(entries, context, limit) {
    const ctx = String(context || '').toLowerCase();
    const lim = limit || 50;
    const scoreOne = (e) => {
      let s = 0;
      const name = String(e.name || '').toLowerCase();
      const hay = [
        e.name,
        ...(e.triggers || []),
        e.embed_text || '',
        ...(e.entities || []),
        ...(e.parties || []),
        ...((e.detail && e.detail.parties) || [])
      ].join(' ').toLowerCase();
      if (name && ctx.includes(name)) s += 120;
      for (const t of (e.triggers || [])) {
        if (!t || t.length < 2) continue;
        const parts = String(t).split('&&').map(p => p.trim().toLowerCase()).filter(Boolean);
        if (parts.length && parts.every(p => ctx.includes(p))) { s += parts.length > 1 ? 80 : 30; break; }
      }
      if (e.anchor) s += 100;
      if (e.isCurrentArc) s += 60;
      if (e.type === 'rel' || e.type === 'relationship' || e.type === 'prom' || e.type === 'promise') s += 30;
      s += (e.imp || 5) + (e.emo || 0) + (e.sur || 0);
      if (e.lastUpdated) s += Math.max(0, 30 - Math.floor((Date.now() - e.lastUpdated) / 86400000));
      if (hay && ctx && hay.split(/\s+/).some(w => w.length >= 2 && ctx.includes(w))) s += 10;
      return s;
    };
    return [...(entries || [])].map(e => ({ e, s: scoreOne(e) })).sort((a,b) => b.s - a.s).slice(0, lim).map(x => x.e);
  }

  function entryDigestForExtract(e) {
    const summary = e.summary && typeof e.summary === 'object'
      ? { compact: e.summary.compact || e.summary.full || '', micro: e.summary.micro || '' }
      : { compact: String(e.summary || e.inject?.compact || '').slice(0, 180), micro: '' };
    const out = {
      id: e.id,
      type: e.type,
      name: e.name,
      state: e.state || e.detail?.status || e.detail?.current_status || '',
      triggers: (e.triggers || []).slice(0, 6),
      summary,
      entities: (e.entities || e.parties || e.detail?.parties || []).slice(0, 8),
      anchor: e.anchor === true ? true : undefined
    };
    if (e.callState) out.callState = e.callState;
    if (Array.isArray(e.eventHistory) && e.eventHistory.length) out.eventHistoryTail = e.eventHistory.slice(-3);
    if (e.type === 'prom' || e.type === 'promise') out.cond = e.cond || e.detail?.condition || '';
    return out;
  }

  function buildExistingLoreContext(entries, context, limit) {
    const selected = selectExistingForContext(entries, context, limit || 20);
    return JSON.stringify(selected.map(entryDigestForExtract), null, 2);
  }

  function normKey(v) {
    return String(v || '').trim().toLowerCase().replace(/\s+/g, '');
  }

  function arrOverlapScore(a, b) {
    const aa = new Set((Array.isArray(a) ? a : []).map(normKey).filter(Boolean));
    const bb = new Set((Array.isArray(b) ? b : []).map(normKey).filter(Boolean));
    let n = 0;
    for (const x of aa) if (bb.has(x)) n++;
    return n;
  }

  function stableForCompare(v) {
    if (Array.isArray(v)) return v.map(stableForCompare);
    if (v && typeof v === 'object') {
      const out = {};
      Object.keys(v).sort().forEach(k => {
        if (['id', 'ts', 'lastUpdated', 'lastMigrationAt', 'localMigrationVersion', 'migratedFromVersion', 'gateScore'].includes(k)) return;
        if (k.startsWith('_')) return;
        out[k] = stableForCompare(v[k]);
      });
      return out;
    }
    return v;
  }

  function entryContentSignature(entry) {
    try { return JSON.stringify(stableForCompare(entry || {})); }
    catch (_) { return String(entry && entry.name || '') + '|' + String(entry && entry.type || ''); }
  }

  function entryParties(e) {
    let parties = e.parties || e.entities || e.detail?.parties || [];
    if ((!Array.isArray(parties) || parties.length < 2) && typeof e.name === 'string') {
      if (e.name.includes('↔')) parties = e.name.split('↔').map(s => s.trim()).filter(Boolean);
      else if (e.name.includes('&')) parties = e.name.split('&').map(s => s.trim()).filter(Boolean);
    }
    return Array.isArray(parties) ? parties : [];
  }

  async function findExistingForIncoming(packName, e) {
    const TL_TYPE_MERGE = C.TIMELINE_EVENT_TYPE || 'timeline_event';
    if (!e || !e.name) return null;
    if (e.id != null) {
      const byId = await db.entries.get(e.id);
      if (byId && byId.packName === packName) return byId;
    }
    if (e.type === TL_TYPE_MERGE) return null;
    const candidates = await db.entries.where('packName').equals(packName).and(x => x.type !== TL_TYPE_MERGE).toArray();
    const nName = normKey(e.name);
    const nType = normKey(e.type);
    const eTriggers = e.triggers || [];
    const eEntities = e.entities || e.parties || e.detail?.parties || [];
    const eParties = entryParties(e).map(normKey).sort().join('|');
    let best = null, bestScore = 0;
    for (const x of candidates) {
      const sameType = normKey(x.type) === nType || (['rel','relationship'].includes(nType) && ['rel','relationship'].includes(normKey(x.type))) || (['prom','promise'].includes(nType) && ['prom','promise'].includes(normKey(x.type)));
      if (!sameType) continue;
      let score = 0;
      if (normKey(x.name) === nName) score += 100;
      const xParties = entryParties(x).map(normKey).sort().join('|');
      if (eParties && xParties && eParties === xParties) score += 90;
      score += arrOverlapScore(eTriggers, x.triggers) * 30;
      score += arrOverlapScore(eEntities, x.entities || x.parties || x.detail?.parties) * 20;
      if (nName && (normKey(x.name).includes(nName) || nName.includes(normKey(x.name)))) score += 25;
      if (score > bestScore) { bestScore = score; best = x; }
    }
    return bestScore >= 60 ? best : null;
  }

  function hasMeaningfulPatchModeFullUpdate(existing, incoming) {
    if (!existing || !incoming) return true;
    const newTriggers = arrOverlapScore(incoming.triggers || [], existing.triggers || []) < (incoming.triggers || []).filter(Boolean).length;
    const newEntities = arrOverlapScore(incoming.entities || incoming.parties || incoming.detail?.parties || [], existing.entities || existing.parties || existing.detail?.parties || []) < (incoming.entities || incoming.parties || incoming.detail?.parties || []).filter(Boolean).length;
    const oldState = existing.state || existing.detail?.current_status || existing.detail?.status || existing.detail?.current_state || '';
    const newState = incoming.state || incoming.detail?.current_status || incoming.detail?.status || incoming.detail?.current_state || '';
    if (newState && normKey(newState) !== normKey(oldState)) return true;
    if (incoming.cond !== undefined && normKey(incoming.cond) !== normKey(existing.cond)) return true;
    if (newTriggers || newEntities) return true;
    if (Array.isArray(incoming.callDelta) && incoming.callDelta.length) return true;
    if (Array.isArray(incoming.eventHistory) && incoming.eventHistory.some(ev => {
      const s = String(ev && ev.summary || '').trim();
      return s && !(existing.eventHistory || []).some(x => String(x && x.summary || '').trim() === s);
    })) return true;
    return false;
  }

  function hasMeaningfulTemporalFullUpdate(existing, incoming) {
    if (!existing || !incoming) return true;
    if (incoming.location && normKey(incoming.location) !== normKey(existing.location)) return true;
    const keys = ['participants', 'actions', 'hooks', 'linkedLore', 'recallTriggers'];
    for (const k of keys) {
      const arr = incoming[k] || [];
      if (Array.isArray(arr) && arr.length && arrOverlapScore(arr, existing[k] || []) < arr.filter(Boolean).length) return true;
    }
    const oldAnchor = existing.when?.anchor || '';
    const newAnchor = incoming.when?.anchor || '';
    if (newAnchor && normKey(newAnchor) !== normKey(oldAnchor)) return true;
    return false;
  }

  async function applyExtractPatchOp(op, packName, chatKey) {
    if (!op || op.op !== 'patch' || op.id == null) return 0;
    let existing = await db.entries.get(op.id);
    if (!existing || existing.packName !== packName) return 0;
    const beforeSig = entryContentSignature(existing);

    const anchorGuard = existing.anchor === true;
    try { if (C.saveEntryVersion) await C.saveEntryVersion(existing, 'extract_patch'); } catch (_) {}

    const set = anchorGuard ? {} : (op.set || {});
    const append = op.append || {};

    if (set.state !== undefined) existing.state = set.state;
    if (set.cond !== undefined) existing.cond = set.cond;
    if (set.summary) existing.summary = C.mergeLoreSummary
      ? C.mergeLoreSummary(existing.summary, set.summary, existing.name, set.state || existing.state)
      : { ...(existing.summary || {}), ...set.summary };
    if (set.inject) existing.inject = mergeInject(existing.inject, set.inject, existing.name, set.state || existing.state);
    if (set.callState) existing.callState = mergeCallState(existing.callState, set.callState);
    if (set.timeline) existing.timeline = { ...(existing.timeline || {}), ...set.timeline };
    if (Array.isArray(set.entities)) existing.entities = mergeArrayUnique(existing.entities, set.entities);
    if (set.detail && typeof set.detail === 'object') existing.detail = { ...(existing.detail || {}), ...set.detail };

    if (Array.isArray(append.triggers) && append.triggers.length) {
      existing.triggers = Array.from(new Set([...(existing.triggers || []), ...append.triggers].filter(Boolean)));
    }

    if (Array.isArray(append.eventHistory) && append.eventHistory.length) {
      existing.eventHistory = existing.eventHistory || [];
      for (const ev of append.eventHistory) {
        if (!ev || !ev.summary) continue;
        const norm = String(ev.summary).trim();
        if (!norm || existing.eventHistory.some(x => x.summary === norm)) continue;
        existing.eventHistory.push({
          turn: ev.turn || getTurnCounter(chatKey),
          summary: norm,
          imp: ev.imp || 5,
          emo: ev.emo || 5,
          ts: Date.now()
        });
      }
      existing.eventHistory.sort((a, b) => (a.turn || 0) - (b.turn || 0));
      if (existing.eventHistory.length > 30) existing.eventHistory = existing.eventHistory.slice(-30);
    }

    if (Array.isArray(append.callHistory) && append.callHistory.length) {
      existing.callHistory = existing.callHistory || [];
      for (const h of append.callHistory) {
        if (!h || !h.from || !h.to || !h.term) continue;
        existing.callHistory.push({
          turn: h.turn || getTurnCounter(chatKey),
          from: h.from,
          to: h.to,
          term: h.term,
          prevTerm: h.prevTerm || null,
          ts: Date.now()
        });
      }
      if (existing.callHistory.length > 30) existing.callHistory = existing.callHistory.slice(-30);
    }

    existing.lastUpdated = Date.now();
    try { if (C.normalizeTemporalGraph) existing = C.normalizeTemporalGraph(existing, { currentTurn: getTurnCounter(chatKey), sceneId: chatKey }); } catch (_) {}
    if (entryContentSignature(existing) === beforeSig) return 0;
    try { if (C.invalidateEntryEmbeddings) await C.invalidateEntryEmbeddings(existing.id); } catch (_) {}
    await db.entries.put(existing);
    return 1;
  }

  async function applyTemporalPatchOp(op, packName, chatKey) {
    if (!op || op.op !== 'patch' || op.id == null) return 0;
    let existing = await db.entries.get(op.id);
    const TL_TYPE = C.TIMELINE_EVENT_TYPE || 'timeline_event';
    if (!existing || existing.packName !== packName || existing.type !== TL_TYPE) return 0;
    const beforeSig = entryContentSignature(existing);

    try { if (C.saveEntryVersion) await C.saveEntryVersion(existing, 'temporal_patch'); } catch (_) {}
    const set = op.set || {};
    const append = op.append || {};

    if (set.title !== undefined) existing.title = set.title;
    if (set.name !== undefined) existing.name = set.name;
    if (set.when && typeof set.when === 'object') existing.when = { ...(existing.when || {}), ...set.when };
    if (set.location !== undefined) existing.location = set.location;
    if (set.summary) existing.summary = C.mergeLoreSummary
      ? C.mergeLoreSummary(existing.summary, set.summary, existing.name)
      : { ...(existing.summary || {}), ...set.summary };

    const appendArr = (key) => {
      if (Array.isArray(append[key]) && append[key].length) {
        existing[key] = mergeArrayUnique(existing[key], append[key]);
      }
    };
    appendArr('participants');
    appendArr('actions');
    appendArr('hooks');
    appendArr('linkedLore');
    appendArr('recallTriggers');
    if (Array.isArray(append.recallTriggers) && append.recallTriggers.length) {
      existing.triggers = mergeArrayUnique(existing.triggers, append.recallTriggers);
    }

    existing.lastUpdated = Date.now();
    try { if (C.normalizeTemporalGraph) existing = C.normalizeTemporalGraph(existing, { currentTurn: getTurnCounter(chatKey), sceneId: chatKey }); } catch (_) {}
    if (entryContentSignature(existing) === beforeSig) return 0;
    try { if (C.invalidateEntryEmbeddings) await C.invalidateEntryEmbeddings(existing.id); } catch (_) {}
    await db.entries.put(existing);
    return 1;
  }

  function isExtractItemObject(item) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return false;
    if (item.op === 'patch' || item.op === 'add') return true;
    if (item.entry && typeof item.entry === 'object') return true;
    return !!(item.name || item.title || item.type || item.summary || item.keywords || item.content);
  }

  function normalizeExtractItems(entries) {
    if (Array.isArray(entries)) return entries.filter(Boolean);
    if (entries && !Array.isArray(entries)) {
      const arrayKeys = ['entries', 'items', 'patches', 'events', 'lore', 'lores', 'memories', 'results'];
      for (const key of arrayKeys) {
        if (Array.isArray(entries[key])) return entries[key].filter(Boolean);
      }
      if (entries.data && typeof entries.data === 'object') {
        const nested = normalizeExtractItems(entries.data);
        if (nested.length) return nested;
      }
      if (entries.output && typeof entries.output === 'object') {
        const nested = normalizeExtractItems(entries.output);
        if (nested.length) return nested;
      }
      if (isExtractItemObject(entries)) return [entries];
    }
    return [];
  }

  function isRecognizedExtractResponse(value) {
    if (Array.isArray(value)) return true;
    if (!value || typeof value !== 'object') return false;
    const arrayKeys = ['entries', 'items', 'patches', 'events', 'lore', 'lores', 'memories', 'results', 'timeline_events'];
    if (arrayKeys.some(key => Array.isArray(value[key]))) return true;
    if (isExtractItemObject(value)) return true;
    if (value.data && typeof value.data === 'object' && isRecognizedExtractResponse(value.data)) return true;
    if (value.output && typeof value.output === 'object' && isRecognizedExtractResponse(value.output)) return true;
    return false;
  }

  function normalizeTemporalCandidates(parsed, limit) {
    let arr = parsed;
    if (arr && !Array.isArray(arr)) {
      const arrayKeys = ['events', 'entries', 'items', 'timeline_events', 'memories', 'results'];
      for (const key of arrayKeys) {
        if (Array.isArray(arr[key])) { arr = arr[key]; break; }
      }
    }
    if (arr && !Array.isArray(arr) && arr.data && typeof arr.data === 'object') arr = normalizeExtractItems(arr.data);
    if (arr && !Array.isArray(arr) && arr.output && typeof arr.output === 'object') arr = normalizeExtractItems(arr.output);
    if (arr && !Array.isArray(arr) && isExtractItemObject(arr)) arr = [arr];
    if (!Array.isArray(arr)) return [];
    const max = Math.max(1, limit || 5);
    const clamp10 = (v, fb) => {
      const n = Number(v);
      if (!Number.isFinite(n)) return fb;
      return Math.max(1, Math.min(10, Math.round(n)));
    };
    return arr
      .filter(e => e && typeof e === 'object')
      .filter(e => e.op !== 'patch')
      .map(e => {
        const raw = (e.op === 'add' && e.entry) ? e.entry : e;
        const title = raw.title || raw.name || raw.summary?.micro || raw.summary?.compact || 'timeline event';
        // Phase 11 gate compatibility: derive imp/emo/sur from importance/emotional/surprise/confidence so timeline events pass mergeExtractedData gating.
        const impBase = raw.imp != null ? raw.imp : raw.importance;
        const emoBase = raw.emo != null ? raw.emo : raw.emotional;
        const surBase = raw.sur != null ? raw.sur : (raw.surprise != null ? raw.surprise : (raw.confidence != null ? Number(raw.confidence) * 10 : null));
        const imp = clamp10(impBase, 6);
        const emo = clamp10(emoBase, 5);
        const sur = clamp10(surBase, 6);
        return {
          ...raw,
          type: C.TIMELINE_EVENT_TYPE || 'timeline_event',
          title,
          name: raw.name || title,
          imp, emo, sur,
          gs: imp + emo + sur,
          source: raw.source || 'temporal_extracted'
        };
      })
      .filter(e => e.name)
      .slice(0, max);
  }

  async function callGeminiJsonWithRepair(prompt, apiOpts, repairHint) {
    const isDeepSeek = apiOpts && apiOpts.apiType === 'deepseek';
    const finalPrompt = isDeepSeek ? `${prompt}

Structured output reminder:
- Return exactly one valid json object.
- The top-level shape is {"entries":[...]}.
- No markdown, no prose, no comments, no trailing text.` : prompt;
    let res = await C.callGeminiApi(finalPrompt, apiOpts);
    let parsed = parseJsonLoose(res && res.text);
    let validStructure = isRecognizedExtractResponse(parsed);
    const shouldRepair = !!(res && res.text) && !validStructure && apiOpts;
    if (shouldRepair) {
      const firstCost = res && res.cost;
      const safeRepairHint = isDeepSeek
        ? String(repairHint || '')
            .replace(/one JSON array/gi, 'one JSON object with an entries array')
            .replace(/complete JSON array/gi, 'complete JSON object with an entries array')
            .replace(/Wrap patch\/add items in an array\./gi, 'Wrap patch/add items in {"entries":[...]}.')
        : (repairHint || '');
      const retryPrompt = finalPrompt + '\n\nJSON REPAIR REQUEST:\n- Your previous response was not valid complete JSON, or it was truncated.\n' + (isDeepSeek
        ? '- Return only one complete JSON object in this exact shape: {"entries":[...]}.\n- If there is no change, return exactly {"entries":[]}.\n'
        : '- Return only one complete JSON array.\n- If there is no change, return exactly [].\n') + safeRepairHint;
      res = await C.callGeminiApi(retryPrompt, {
          ...apiOpts,
          maxRetries: 0,
          responseMimeType: 'application/json'
      });
      parsed = parseJsonLoose(res && res.text);
      validStructure = isRecognizedExtractResponse(parsed);
      if (res && firstCost && res.cost) {
        const retryCost = res.cost;
        const unknown = !!(firstCost.unknown || retryCost.unknown || firstCost.usd == null || retryCost.usd == null);
        res.cost = {
          ...retryCost,
          inTok: (Number(firstCost.inTok) || 0) + (Number(retryCost.inTok) || 0),
          outTok: (Number(firstCost.outTok) || 0) + (Number(retryCost.outTok) || 0),
          usd: unknown ? null : ((Number(firstCost.usd) || 0) + (Number(retryCost.usd) || 0)),
          unknown,
          estimated: !!(firstCost.estimated || retryCost.estimated),
          repairRetry: true
        };
      }
    }
    if (!validStructure) parsed = null;
    return { res, parsed };
  }

  function temporalDigestForExtract(e) {
    const summary = e.summary && typeof e.summary === 'object'
      ? { compact: e.summary.compact || e.summary.full || '', micro: e.summary.micro || '' }
      : { compact: String(e.summary || '').slice(0, 180), micro: '' };
    return {
      id: e.id,
      eventId: e.eventId,
      title: e.title || e.name,
      name: e.name,
      when: e.when ? { anchor: e.when.anchor || '', relative: e.when.relative || '', turnStart: e.when.turnStart || e.timeline?.eventTurn || 0 } : undefined,
      participants: (e.participants || e.entities || []).slice(0, 8),
      location: e.location || '',
      actions: (e.actions || []).slice(0, 6),
      hooks: (e.hooks || []).slice(0, 6),
      recallTriggers: (e.recallTriggers || e.triggers || []).slice(0, 8),
      summary
    };
  }

  function injectTemporalExistingBlock(prompt, existingText, outputModeText) {
    const block = `${outputModeText || ''}

Existing Important Scene Memories:
${existingText}

DEDUP RULE:
- Output [] if the conversation only repeats or overlaps with the existing memories above.
- Do not restate, rename, or re-summarize an existing memory.
- Output only genuinely new important scene memories not already covered above.
`;
    const marker = '\nConversation Log:';
    const idx = prompt.indexOf(marker);
    if (idx >= 0) return prompt.slice(0, idx) + '\n' + block + prompt.slice(idx);
    return prompt + '\n\n' + block;
  }

  function getDeepSeekTemplatePrompt(tpl, templateKey, legacyKey, fallback) {
    if (tpl && tpl[templateKey]) return tpl[templateKey];
    if (settings.config && settings.config[legacyKey]) return settings.config[legacyKey];
    return fallback || '';
  }

  function shouldUseDeepSeekPromptOverride(apiType) {
    return apiType === 'deepseek' && settings.config.deepSeekPromptOverridesEnabled !== false;
  }

  function getLoreExtractPrompt(tpl, includeDb, apiType) {
    if (shouldUseDeepSeekPromptOverride(apiType)) {
      return includeDb
        ? getDeepSeekTemplatePrompt(tpl, 'deepSeekPromptWithDb', 'deepSeekPromptWithDb', _w.__LoreInj.DEFAULT_DEEPSEEK_AUTO_EXTRACT_PROMPT_WITH_DB || (tpl && tpl.promptWithDb))
        : getDeepSeekTemplatePrompt(tpl, 'deepSeekPromptWithoutDb', 'deepSeekPromptWithoutDb', _w.__LoreInj.DEFAULT_DEEPSEEK_AUTO_EXTRACT_PROMPT_WITHOUT_DB || (tpl && tpl.promptWithoutDb));
    }
    return includeDb ? tpl.promptWithDb : tpl.promptWithoutDb;
  }

  async function collectTemporalExtractItems(opts = {}) {
    if (settings.config.temporalExtractEnabled === false) return { count: 0, skipped: true, patches: [], events: [] };
    const context = opts.context || '';
    const apiOpts = opts.apiOpts || {};
    const url = opts.url || C.getCurUrl();
    const chatKey = opts.chatKey || getChatKey();
    const isDeepSeekTemporal = apiOpts && apiOpts.apiType === 'deepseek';
    const activeTpl = settings.getActiveTemplate ? settings.getActiveTemplate() : null;
    const promptTpl = isDeepSeekTemporal && settings.config.deepSeekPromptOverridesEnabled !== false
      ? getDeepSeekTemplatePrompt(activeTpl, 'deepSeekTemporalExtractPrompt', 'deepSeekTemporalExtractPrompt', _w.__LoreInj.DEFAULT_DEEPSEEK_TEMPORAL_EXTRACT_PROMPT || DEFAULT_TEMPORAL_EXTRACT_PROMPT)
      : (settings.config.temporalExtractPrompt || DEFAULT_TEMPORAL_EXTRACT_PROMPT);
    const baseTemporalSchema = settings.config.temporalExtractSchema || DEFAULT_TEMPORAL_EXTRACT_SCHEMA;
    const schema = `${baseTemporalSchema}

Patch-mode alternative when OUTPUT MODE asks for SAVE ONLY CHANGES:
${TEMPORAL_PATCH_SCHEMA}`;
    if (!promptTpl || !schema || !context) return { count: 0, skipped: true, patches: [], events: [] };

    const packName = await getAutoExtPackForUrl(url);
    const _patchOn = settings.config.autoExtIncludeDb && settings.config.autoExtPatchMode !== false;
    let existingTemporalText = '[]';
    try {
      const TL_TYPE = C.TIMELINE_EVENT_TYPE || 'timeline_event';
      const existingTemporal = await db.entries.where('packName').equals(packName).and(e => e.type === TL_TYPE).toArray();
      if (existingTemporal.length) {
        existingTemporal.sort((a, b) => (b.lastUpdated || b.ts || 0) - (a.lastUpdated || a.ts || 0));
        existingTemporalText = JSON.stringify(existingTemporal.slice(0, 30).map(temporalDigestForExtract), null, 2);
      }
    } catch (_) {}

    const outputModeText = providerOutputMode(_patchOn ? TEMPORAL_OUTPUT_MODE_PATCH : TEMPORAL_OUTPUT_MODE_FULL, apiOpts, 'temporal');
    const prompt = injectTemporalExistingBlock(promptTpl.replace('{context}', context).replace('{schema}', schema), existingTemporalText, outputModeText);
    const temporalOverrides = {
      model: (apiOpts && apiOpts.model) || (settings.config.autoExtModel === '_custom' ? settings.config.autoExtCustomModel : settings.config.autoExtModel),
      responseMimeType: 'application/json',
      maxRetries: apiOpts.maxRetries != null ? apiOpts.maxRetries : 1,
      timeoutMs: apiOpts.timeoutMs || (isDeepSeekTemporal ? 150000 : 120000),
    };
    const temporalApiOpts = _w.__LoreInj.buildGenerationApiOpts
      ? _w.__LoreInj.buildGenerationApiOpts(temporalOverrides, { feature: 'temporalExtract', chatKey: chatKey || 'global' })
      : { ...apiOpts, ...temporalOverrides, costContext: { feature: 'temporalExtract', chatKey: chatKey || 'global' } };
    const t0 = Date.now();
    const { res, parsed } = await callGeminiJsonWithRepair(prompt, temporalApiOpts, 'Use patch objects only when a real timeline memory changes.');
    const apiLog = res ? { status: res.status, error: res.error, retries: res.retries } : null;
    if (!res || !res.text) throw new Error('시간축 AI 응답없음 (' + ((res && res.error) || '알수없음') + ')');
    if (!parsed) throw new Error('시간축 JSON 파싱 실패 (응답 스니포: ' + (res.text || '').slice(0, 100) + ')');
    const rawItems = normalizeExtractItems(parsed);
    const patches = rawItems.filter(item => item && item.op === 'patch');
    const events = normalizeTemporalCandidates(parsed, settings.config.temporalMaxEventsPerPass || 5);
    return {
      count: patches.length + events.length,
      empty: patches.length + events.length <= 0,
      patches,
      events,
      api: apiLog,
      elapsedMs: Date.now() - t0,
      cost: (res && res.cost) || null
    };
  }

  async function runTemporalExtractPass(opts = {}) {
    if (settings.config.temporalExtractEnabled === false) return { count: 0, skipped: true };
    const context = opts.context || '';
    const apiOpts = opts.apiOpts || {};
    const url = opts.url || C.getCurUrl();
    const chatKey = opts.chatKey || getChatKey();
    const isManual = !!opts.isManual;
    const msgCount = opts.msgCount || 0;
    const skipEmbedding = !!opts.skipEmbedding;
    const isDeepSeekTemporal = apiOpts && apiOpts.apiType === 'deepseek';
    const activeTpl = settings.getActiveTemplate ? settings.getActiveTemplate() : null;
    const promptTpl = isDeepSeekTemporal && settings.config.deepSeekPromptOverridesEnabled !== false
      ? getDeepSeekTemplatePrompt(activeTpl, 'deepSeekTemporalExtractPrompt', 'deepSeekTemporalExtractPrompt', _w.__LoreInj.DEFAULT_DEEPSEEK_TEMPORAL_EXTRACT_PROMPT || DEFAULT_TEMPORAL_EXTRACT_PROMPT)
      : (settings.config.temporalExtractPrompt || DEFAULT_TEMPORAL_EXTRACT_PROMPT);
    const baseTemporalSchema = settings.config.temporalExtractSchema || DEFAULT_TEMPORAL_EXTRACT_SCHEMA;
    const schema = `${baseTemporalSchema}

Patch-mode alternative when OUTPUT MODE asks for SAVE ONLY CHANGES:
${TEMPORAL_PATCH_SCHEMA}`;
    if (!promptTpl || !schema || !context) return { count: 0, skipped: true };

    const _tmpModel = (apiOpts && apiOpts.model) || null;
    let apiLog = null, _tmpElapsedMs = 0, _tmpCost = null;
    try {
      const packName = await getAutoExtPackForUrl(url);
      const _patchOn = settings.config.autoExtIncludeDb && settings.config.autoExtPatchMode !== false;
      let existingTemporalText = '[]';
      try {
        const TL_TYPE = C.TIMELINE_EVENT_TYPE || 'timeline_event';
        const existingTemporal = await db.entries.where('packName').equals(packName).and(e => e.type === TL_TYPE).toArray();
        if (existingTemporal.length) {
          existingTemporal.sort((a, b) => (b.lastUpdated || b.ts || 0) - (a.lastUpdated || a.ts || 0));
          existingTemporalText = JSON.stringify(existingTemporal.slice(0, 30).map(temporalDigestForExtract), null, 2);
        }
      } catch (_) {}

      const outputModeText = providerOutputMode(_patchOn ? TEMPORAL_OUTPUT_MODE_PATCH : TEMPORAL_OUTPUT_MODE_FULL, apiOpts, 'temporal');
      const prompt = injectTemporalExistingBlock(promptTpl.replace('{context}', context).replace('{schema}', schema), existingTemporalText, outputModeText);
      const _tmpT0 = Date.now();
      // v1.4.0-test.41 (B20 fix): 시간축 추출 패스는 'autoExtract'가 아닌 별도 feature로 기록. 이전에는 _doExtract의 apiOpts.costContext가 그대로 전달돼 자동추출 비용과 잡혀 분석 증감.
      const temporalOverrides = {
        model: (apiOpts && apiOpts.model) || (settings.config.autoExtModel === '_custom' ? settings.config.autoExtCustomModel : settings.config.autoExtModel),
        responseMimeType: 'application/json',
        maxRetries: apiOpts.maxRetries != null ? apiOpts.maxRetries : 1,
        timeoutMs: apiOpts.timeoutMs || (isDeepSeekTemporal ? 150000 : 120000),
      };
      const temporalApiOpts = _w.__LoreInj.buildGenerationApiOpts
        ? _w.__LoreInj.buildGenerationApiOpts(temporalOverrides, { feature: 'temporalExtract', chatKey: chatKey || 'global' })
        : { ...apiOpts, ...temporalOverrides, costContext: { feature: 'temporalExtract', chatKey: chatKey || 'global' } };
      const { res, parsed } = await callGeminiJsonWithRepair(prompt, temporalApiOpts, 'Use patch objects only when a real timeline memory changes.');
      _tmpElapsedMs = Date.now() - _tmpT0;
      _tmpCost = (res && res.cost) || null;
      apiLog = res ? { status: res.status, error: res.error, retries: res.retries } : null;
      if (!res || !res.text) throw new Error('시간축 AI 응답없음 (' + ((res && res.error) || '알수없음') + ')');
      if (!parsed) throw new Error('시간축 JSON 파싱 실패 (응답 스니포: ' + (res.text || '').slice(0, 100) + ')');
      let patchedCount = 0;
      for (const item of normalizeExtractItems(parsed)) {
        if (item && item.op === 'patch') patchedCount += await applyTemporalPatchOp(item, packName, chatKey);
      }
      const events = normalizeTemporalCandidates(parsed, settings.config.temporalMaxEventsPerPass || 5);
      if (!events.length && patchedCount <= 0) {
        addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count: 0, msgs: msgCount, isManual, status: '시간축 추출 내용 없음', api: apiLog, model: _tmpModel, elapsedMs: _tmpElapsedMs, cost: _tmpCost });
        return { count: 0, empty: true };
      }
      const addCount = events.length ? await mergeExtractedData(events, url) : 0;
      const count = patchedCount + addCount;
      let embedMsg = '';
      let embedCount = 0;
      if (!skipEmbedding && count > 0 && settings.config.embeddingEnabled && settings.config.autoEmbedOnExtract !== false) {
        try {
          const epName = await getAutoExtPackForUrl(url);
          extBadgeShow('에리가 장면 기억 검색 준비 중');
          const embedOpts = _w.__LoreInj.buildEmbeddingApiOpts
            ? _w.__LoreInj.buildEmbeddingApiOpts({ model: settings.config.embeddingModel || 'gemini-embedding-001' }, { feature: 'embed', chatKey: chatKey || 'global' })
            : {
              apiType: (settings.config.autoExtApiType || 'key') === 'deepseek' ? 'key' : (settings.config.autoExtApiType || 'key'),
              key: (settings.config.autoExtApiType || 'key') === 'deepseek' ? settings.config.autoExtFirebaseEmbedKey : settings.config.autoExtKey,
              vertexJson: settings.config.autoExtVertexJson,
              vertexLocation: settings.config.autoExtVertexLocation || 'global',
              vertexProjectId: settings.config.autoExtVertexProjectId,
              firebaseScript: settings.config.autoExtFirebaseScript,
              firebaseEmbedKey: settings.config.autoExtFirebaseEmbedKey,
              model: settings.config.embeddingModel || 'gemini-embedding-001',
              costContext: { feature: 'embed', chatKey: chatKey || 'global' }
            };
          embedCount = await C.embedPack(epName, embedOpts);
          embedMsg = ' / 검색 준비 ' + embedCount + '개 완료';
        } catch(embErr) {
          console.warn('[Lore] 시간축 자동임베딩 실패:', embErr.message);
          embedMsg = ' / 검색 준비 실패';
        }
      }
      addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count, msgs: msgCount, isManual, status: '시간축 추출 성공' + embedMsg, api: apiLog, model: _tmpModel, elapsedMs: _tmpElapsedMs, cost: _tmpCost });
      return { count, events };
    } catch (err) {
      console.warn('[Lore:temporal] 추출 실패:', err);
      addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count: 0, msgs: msgCount, isManual, status: '시간축 추출 실패', error: err.message || String(err), api: apiLog, model: _tmpModel, elapsedMs: _tmpElapsedMs, cost: _tmpCost });
      return { count: 0, error: err.message || String(err) };
    }
  }

  async function mergeExtractedData(entries, url, options = {}) {
    const packName = await getAutoExtPackForUrl(url);
    const chatKey = getChatKey();
    let ap = [...(settings.config.autoPacks || [])];
    if (!ap.includes(packName)) { ap.push(packName); settings.config.autoPacks = ap; settings.save(); }
    const proj = settings.config.activeProject || '';
    let pack = await db.packs.get(packName);
    if (!pack) await db.packs.put({ name: packName, entryCount: 0, project: proj });
    else if (!options.skipSnapshot) await createSnapshot(packName, '자동 병합 전 백업', 'auto');

    let processedCount = 0;
    for (const item of normalizeExtractItems(entries)) {
      if (!item) continue;
      if (item.op === 'patch') {
        processedCount += await applyExtractPatchOp(item, packName, chatKey);
        continue;
      }
      let e = (item.op === 'add' && item.entry) ? item.entry : item;
      if (!e.name) continue;
      e = normalizeEntryForMerge(e, getTurnCounter(chatKey));
      e.gs = (e.imp || 5) + (e.sur || 5) + (e.emo || 5);
      if (settings.config.importanceGating !== false) {
        if (e.gs < (settings.config.importanceThreshold || 12)) continue;
        e.gateScore = e.gs;
      }
      processedCount++;
      const TL_TYPE_MERGE = C.TIMELINE_EVENT_TYPE || 'timeline_event';
      // Phase 12: timeline_event는 stable id / when.anchor / type 매칭으로 분리해 일반 lore와 의도치 않게 합쳐지지 않게 한다.
      if (e.type === TL_TYPE_MERGE && C.stableTimelineEventId && !e.eventId) {
        try { e.eventId = C.stableTimelineEventId(e); } catch(_) {}
      }
      let existing;
      if (e.type === TL_TYPE_MERGE) {
        const _tlId = e.eventId || (C.stableTimelineEventId ? (function(){ try { return C.stableTimelineEventId(e); } catch(_) { return null; } })() : null);
        if (_tlId) {
          existing = await db.entries.where('packName').equals(packName).and(x => {
            if (x.type !== TL_TYPE_MERGE) return false;
            if (x.eventId === _tlId) return true;
            try { return !!(C.stableTimelineEventId && C.stableTimelineEventId(x) === _tlId); } catch(_) { return false; }
          }).first();
        }
        if (!existing) {
          const _wa = e.when && e.when.anchor ? String(e.when.anchor) : '';
          existing = await db.entries.where('packName').equals(packName).and(x => x.type === TL_TYPE_MERGE && x.name === e.name && (_wa ? (x.when && x.when.anchor === _wa) : true)).first();
        }
      } else {
        existing = await db.entries.where('packName').equals(packName).and(x => x.name === e.name && x.type !== TL_TYPE_MERGE).first();
        if (!existing) existing = await findExistingForIncoming(packName, e);
      }
      // Full-object fallback from patch mode is allowed through the normal merge path.
      // The after-merge signature check below skips true no-op updates, while still
      // accepting summary/detail/inject changes that the older pre-merge guard missed.
      // Phase 12: timeline_event union merge backup — 일반 머지 흐름이 단순 spread로 union 필드를 덮어쓰는 것을 방지.
      // Phase 13-fix: anchor 보호된 timeline_event는 union backup도 건너뛴다 (anchor 무결성 우선; participants/hooks 등도 anchor snap이 그대로 보존).
      let _tlMergeBackup = null;
      if (existing && e.type === TL_TYPE_MERGE && existing.anchor !== true) {
        const _mergeArr = (a, b) => Array.from(new Set([...(Array.isArray(a)?a:[]), ...(Array.isArray(b)?b:[])].filter(Boolean)));
        _tlMergeBackup = {
          participants: _mergeArr(existing.participants, e.participants),
          hooks: _mergeArr(existing.hooks, e.hooks),
          recallTriggers: _mergeArr(existing.recallTriggers, e.recallTriggers),
          linkedLore: _mergeArr(existing.linkedLore, e.linkedLore),
          actions: _mergeArr(existing.actions, e.actions),
          when: { ...(existing.when || {}), ...(e.when || {}) }
        };
      }
      if (existing) {
        existing = normalizeEntryForMerge(existing, getTurnCounter(chatKey));
        const _beforeExistingSig = entryContentSignature(existing);
        // 서사 무결성: 덮어쓰기 전 현재 상태 백업 (append-only)
        try { if (C.saveEntryVersion) await C.saveEntryVersion(existing, 'extract_merge'); } catch(ex) {}
        // Narrative Anchor: 앵커 엔트리는 summary/state/detail/call/inject 등 내러티브 필드 보호.
        // 스냅샷 떠놨다가 put 직전 복원. eventHistory/triggers 병합만 허용.
        const _anchorGuard = existing.anchor === true;
        const _anchorSnap = _anchorGuard ? {
          summary: existing.summary,
          state: existing.state,
          detail: existing.detail ? JSON.parse(JSON.stringify(existing.detail)) : undefined,
          call: existing.call ? JSON.parse(JSON.stringify(existing.call)) : undefined,
          callState: existing.callState ? JSON.parse(JSON.stringify(existing.callState)) : undefined,
          callHistory: existing.callHistory ? JSON.parse(JSON.stringify(existing.callHistory)) : undefined,
          inject: existing.inject ? JSON.parse(JSON.stringify(existing.inject)) : undefined,
          timeline: existing.timeline ? JSON.parse(JSON.stringify(existing.timeline)) : undefined,
          entities: existing.entities ? JSON.parse(JSON.stringify(existing.entities)) : undefined,
          cond: existing.cond,
          imp: existing.imp, sur: existing.sur, emo: existing.emo, gs: existing.gs,
          arc: existing.arc ? JSON.parse(JSON.stringify(existing.arc)) : undefined
        } : null;
        if (!_anchorGuard && ['relationship', 'promise', 'rel', 'prom'].includes(e.type)) {
          const oldS = existing.state || existing.detail?.current_status || existing.detail?.status || null;
          const newS = e.state || e.detail?.current_status || e.detail?.status || null;
          if (oldS && newS && oldS !== newS) {
            const cLog = JSON.parse(_ls.getItem('lore-contradictions') || '[]');
            cLog.unshift({ name: e.name, type: e.type, oldStatus: oldS, newStatus: newS, turn: getTurnCounter(chatKey), time: Date.now() });
            if (cLog.length > 50) cLog.length = 50;
            _ls.setItem('lore-contradictions', JSON.stringify(cLog));
          }
        }
        existing.triggers = [...new Set([...(existing.triggers || []), ...(e.triggers || [])])];
        if (e.embed_text) existing.embed_text = e.embed_text;
        if (e.inject) existing.inject = mergeInject(existing.inject, e.inject, existing.name, e.state || existing.state);
        if (e.state !== undefined) existing.state = e.state;
        if (e.call) existing.call = { ...(existing.call || {}), ...e.call };
        if (e.callState) existing.callState = mergeCallState(existing.callState, e.callState);
        if (e.timeline) existing.timeline = { ...(existing.timeline || {}), ...e.timeline };
        if (e.entities) existing.entities = mergeArrayUnique(existing.entities, e.entities);
        if (Array.isArray(e.callDelta) && e.callDelta.length > 0) {
          existing.callHistory = existing.callHistory || [];
          for (const d of e.callDelta) {
            if (!d.from || !d.to || !d.term) continue;
            existing.callHistory.push({
              turn: d.turnApprox || getTurnCounter(chatKey),
              from: d.from, to: d.to, term: d.term,
              prevTerm: d.prevTerm || null, ts: Date.now()
            });
          }
          if (existing.callHistory.length > 30) existing.callHistory = existing.callHistory.slice(-30);
        }
        if (Array.isArray(e.eventHistory) && e.eventHistory.length > 0) {
          existing.eventHistory = existing.eventHistory || [];
          for (const ev of e.eventHistory) {
            if (!ev || !ev.summary) continue;
            const normSum = ev.summary.trim();
            if (existing.eventHistory.some(x => x.summary === normSum)) continue;
            existing.eventHistory.push({
              turn: ev.turn || getTurnCounter(chatKey),
              summary: normSum,
              imp: ev.imp || 5,
              emo: ev.emo || 5,
              ts: Date.now()
            });
          }
          existing.eventHistory.sort((a,b) => (a.turn||0) - (b.turn||0));
          if (existing.eventHistory.length > 30) {
            const oldEvents = existing.eventHistory.slice(0, 20);
            const recentEvents = existing.eventHistory.slice(20);
            const rootId = existing.rootId || existing.id;
            const lastTurn = oldEvents[oldEvents.length - 1]?.turn || 0;
            const firstTurn = oldEvents[0]?.turn || 0;
            const shardEntry = {
              name: `${existing.name} [과거 t${firstTurn}~t${lastTurn}]`,
              type: existing.type,
              packName: existing.packName,
              project: existing.project || '',
              enabled: true,
              triggers: [...(existing.triggers || [])],
              embed_text: existing.embed_text,
              rootId: rootId,
              isCurrentArc: false,
              eventHistory: oldEvents,
              inject: {
                full: `${existing.name}[과거사] ${oldEvents.slice(-2).map(ev => `t${ev.turn}:${ev.summary.slice(0,40)}`).join('|')}`,
                compact: `${existing.name}[과거 ${oldEvents.length}건]`,
                micro: `${existing.name}=과거`
              },
              state: '과거사',
              summary: {
                full: `${existing.name} 과거 이벤트 ${oldEvents.length}건: ${oldEvents.slice(-3).map(ev => `t${ev.turn}:${ev.summary}`).join(' / ')}`,
                compact: `${existing.name} 과거 이벤트 ${oldEvents.length}건`,
                micro: `${existing.name}=과거`
              },
              timeline: { eventTurn: lastTurn, relativeOrder: 'past', sceneLabel: 'archived shard', observedRecency: 'old' },
              entities: existing.entities || existing.parties || existing.detail?.parties || [],
              source: 'shard_split',
              src: 'sh',
              ts: Date.now(),
              lastUpdated: Date.now(),
              imp: existing.imp, emo: existing.emo, sur: existing.sur,
              gs: existing.gs
            };
            await db.entries.put(shardEntry);
            existing.eventHistory = recentEvents;
            existing.rootId = null;
            existing.isCurrentArc = true;
          }
          if (existing.inject && typeof existing.inject === 'object') {
            const base = (existing.inject.full || '').split(' | 최근:')[0];
            const recent = existing.eventHistory.slice(-2).map(ev => `t${ev.turn}:${ev.summary.slice(0,40)}`).join('|');
            existing.inject.full = recent ? base + ' | 최근:' + recent : base;
          }
        }
        if (e.cond !== undefined) existing.cond = e.cond;
        if (e.imp) existing.imp = e.imp;
        if (e.sur) existing.sur = e.sur;
        if (e.emo) existing.emo = e.emo;
        existing.gs = (existing.imp || 5) + (existing.sur || 5) + (existing.emo || 5);
        existing.ts = Date.now();

        if (e.type === 'rel' && Array.isArray(e.arc)) {
          existing.arc = existing.arc || [];
          for (const a of e.arc) {
            const dup = existing.arc.find(x => x.ph === a.ph && x.t === a.t);
            if (dup) Object.assign(dup, a); else existing.arc.push(a);
          }
        }

        if (['relationship', 'promise'].includes(e.type)) {
          if (e.summary) existing.summary = C.mergeLoreSummary ? C.mergeLoreSummary(existing.summary, e.summary, existing.name, e.state || existing.state) : e.summary;
          if (e.detail) {
            existing.detail = existing.detail || {};
            if (e.detail.current_status !== undefined) existing.detail.current_status = e.detail.current_status;
            if (e.detail.status !== undefined) existing.detail.status = e.detail.status;
            if (e.detail.parties) existing.detail.parties = e.detail.parties;
            if (e.detail.condition !== undefined) existing.detail.condition = e.detail.condition;

            if (e.detail.nicknames) {
              existing.detail.nicknames = existing.detail.nicknames || {};
              Object.assign(existing.detail.nicknames, e.detail.nicknames);
            }

            if (Array.isArray(e.detail.arc)) {
              existing.detail.arc = existing.detail.arc || [];
              for (const newArc of e.detail.arc) {
                const dup = existing.detail.arc.find(a => a.phase === newArc.phase && a.approx_turn === newArc.approx_turn);
                if (dup) Object.assign(dup, newArc); else existing.detail.arc.push(newArc);
              }
            }
          }
        } else if (e.type !== 'rel' && e.type !== 'prom') {
          if (e.summary) existing.summary = C.mergeLoreSummary ? C.mergeLoreSummary(existing.summary, e.summary, existing.name, e.state || existing.state) : e.summary;
          if (e.detail) {
            existing.detail = existing.detail || {};
            if (e.detail.current_state !== undefined) existing.detail.current_state = e.detail.current_state;
            if (e.detail.last_interaction !== undefined) existing.detail.last_interaction = e.detail.last_interaction;
            for (const k in e.detail) {
              if (['current_state', 'last_interaction'].includes(k)) continue;
              if (!existing.detail[k]) existing.detail[k] = e.detail[k];
              else if (Array.isArray(e.detail[k])) existing.detail[k] = [...new Set([...(existing.detail[k] || []), ...e.detail[k]])];
              else if (typeof existing.detail[k] === 'string' && typeof e.detail[k] === 'string' && !existing.detail[k].includes(e.detail[k])) existing.detail[k] += ' ' + e.detail[k];
            }
          }
        }
        if (e.gateScore) existing.gateScore = e.gateScore;
        existing.lastUpdated = Date.now();

        if (e.type === 'relationship' || e.type === 'rel') {
          let parties = (e.detail?.parties) || e.parties;
          if ((!parties || parties.length < 2) && typeof e.name === 'string') {
            if (e.name.includes('↔')) parties = e.name.split('↔').map(s => s.trim()).filter(Boolean);
            else if (e.name.includes('&')) parties = e.name.split('&').map(s => s.trim()).filter(Boolean);
          }
          if (parties && parties.length >= 2) {
            const [c1, c2] = parties;
            try { await C.recordFirstEncounter(c1, c2, { turnApprox: getTurnCounter(chatKey), timestamp: Date.now() }); } catch(ex) {}
          }
        }
        // Narrative Anchor: 보호 필드 복원
        if (_anchorSnap) {
          for (const k of Object.keys(_anchorSnap)) {
            if (_anchorSnap[k] === undefined) delete existing[k];
            else existing[k] = _anchorSnap[k];
          }
        }
        // Phase 12: timeline_event 전용 union merge 결과 복원 (일반 머지가 덮어쓴 union 필드 회복).
        if (_tlMergeBackup) {
          if (_tlMergeBackup.participants && _tlMergeBackup.participants.length) existing.participants = _tlMergeBackup.participants;
          if (_tlMergeBackup.hooks && _tlMergeBackup.hooks.length) existing.hooks = _tlMergeBackup.hooks;
          if (_tlMergeBackup.recallTriggers && _tlMergeBackup.recallTriggers.length) existing.recallTriggers = _tlMergeBackup.recallTriggers;
          if (_tlMergeBackup.linkedLore && _tlMergeBackup.linkedLore.length) existing.linkedLore = _tlMergeBackup.linkedLore;
          if (_tlMergeBackup.actions && _tlMergeBackup.actions.length) existing.actions = _tlMergeBackup.actions;
          if (_tlMergeBackup.when && Object.keys(_tlMergeBackup.when).length) existing.when = _tlMergeBackup.when;
        }
        try { if (C.normalizeTemporalGraph) existing = C.normalizeTemporalGraph(existing, { currentTurn: getTurnCounter(chatKey), sceneId: chatKey }); } catch(_) {}
        if (entryContentSignature(existing) === _beforeExistingSig) {
          processedCount--;
          continue;
        }
        try { if (C.invalidateEntryEmbeddings) await C.invalidateEntryEmbeddings(existing.id); } catch(_) {}
        await db.entries.put(existing);
      } else {
        e.packName = packName; e.project = proj; e.enabled = true;
        e.src = e.src || (e.source === 'user_stated' ? 'us' : (e.source === 'imported' ? 'im' : 'ax'));
        e.source = e.source || 'auto_extracted';
        e.ts = Date.now();
        e.lastUpdated = e.ts;
        if ((e.type === 'rel' || e.type === 'relationship') && Array.isArray(e.callDelta) && e.callDelta.length > 0) {
          e.callHistory = e.callHistory || [];
          for (const d of e.callDelta) {
            if (!d.from || !d.to || !d.term) continue;
            e.callHistory.push({
              turn: d.turnApprox || getTurnCounter(chatKey),
              from: d.from, to: d.to, term: d.term,
              prevTerm: d.prevTerm || null, ts: Date.now()
            });
          }
        }
        if (Array.isArray(e.eventHistory) && e.eventHistory.length > 0) {
          e.eventHistory = e.eventHistory.filter(ev => ev && ev.summary).map(ev => ({
            turn: ev.turn || getTurnCounter(chatKey),
            summary: ev.summary.trim(),
            imp: ev.imp || 5, emo: ev.emo || 5, ts: Date.now()
          })).sort((a,b) => (a.turn||0) - (b.turn||0));
          if (e.eventHistory.length > 30) e.eventHistory = e.eventHistory.slice(-30);
          if (e.inject && typeof e.inject === 'object') {
            const base = (e.inject.full || '').split(' | 최근:')[0];
            const recent = e.eventHistory.slice(-2).map(ev => `t${ev.turn}:${ev.summary.slice(0,40)}`).join('|');
            e.inject.full = recent ? base + ' | 최근:' + recent : base;
          }
        }
        try { if (C.normalizeTemporalGraph) e = C.normalizeTemporalGraph(e, { currentTurn: getTurnCounter(chatKey), sceneId: chatKey }); } catch(_) {}
        await db.entries.put(e);
      }
    }
    if (processedCount > 0) {
      const count = await db.entries.where('packName').equals(packName).count();
      await db.packs.update(packName, { entryCount: count });
      await setPackEnabled(packName, true);
    }
    return processedCount;
  }

  function cloneForRollback(value) {
    if (value == null) return value;
    try { return JSON.parse(JSON.stringify(value)); }
    catch (_) { return value; }
  }

  async function snapshotPackState(packName) {
    const entries = await db.entries.where('packName').equals(packName).toArray();
    const entryIds = entries.map(e => e && e.id).filter(id => id != null);
    const readByEntryIds = async (table) => {
      if (!table || !entryIds.length) return [];
      try { return await table.where('entryId').anyOf(entryIds).toArray(); }
      catch (_) { return []; }
    };
    let pack = null, snapshots = [];
    try { pack = await db.packs.get(packName); } catch (_) {}
    try { snapshots = await db.snapshots.where('packName').equals(packName).toArray(); } catch (_) {}
    return {
      packName,
      packExists: !!pack,
      pack: cloneForRollback(pack),
      entries: cloneForRollback(entries) || [],
      embeddings: cloneForRollback(await readByEntryIds(db.embeddings)) || [],
      entryVersions: cloneForRollback(await readByEntryIds(db.entryVersions)) || [],
      snapshots: cloneForRollback(snapshots) || [],
      autoPacks: cloneForRollback(settings.config.autoPacks || []) || []
    };
  }

  async function restorePackState(state) {
    if (!state || !state.packName) return;
    const currentEntries = await db.entries.where('packName').equals(state.packName).toArray();
    const entryIds = Array.from(new Set([...(currentEntries || []), ...(state.entries || [])]
      .map(e => e && e.id).filter(id => id != null)));
    const tables = [db.entries, db.packs, db.snapshots];
    if (db.embeddings) tables.push(db.embeddings);
    if (db.entryVersions) tables.push(db.entryVersions);
    await db.transaction('rw', ...tables, async () => {
      await db.entries.where('packName').equals(state.packName).delete();
      if (state.entries && state.entries.length) await db.entries.bulkPut(cloneForRollback(state.entries));
      if (state.packExists) await db.packs.put(cloneForRollback(state.pack));
      else await db.packs.delete(state.packName);
      if (db.snapshots) {
        await db.snapshots.where('packName').equals(state.packName).delete();
        if (state.snapshots && state.snapshots.length) await db.snapshots.bulkPut(cloneForRollback(state.snapshots));
      }
      if (db.embeddings && entryIds.length) {
        await db.embeddings.where('entryId').anyOf(entryIds).delete();
        if (state.embeddings && state.embeddings.length) await db.embeddings.bulkPut(cloneForRollback(state.embeddings));
      }
      if (db.entryVersions && entryIds.length) {
        await db.entryVersions.where('entryId').anyOf(entryIds).delete();
        if (state.entryVersions && state.entryVersions.length) await db.entryVersions.bulkPut(cloneForRollback(state.entryVersions));
      }
    });
    settings.config.autoPacks = Array.isArray(state.autoPacks) ? [...state.autoPacks] : [];
    settings.save();
  }

  const _extQ = { running: false, pendingTurns: 0, manualPending: false };
  let _extBadgeMsg = null, _extBadgeWatchdog = null;
  function extBadgeShow(msg) {
    if (settings.config.extractStatusBadgeEnabled === false) return;
    _extBadgeMsg = msg;
    try { C.showStatusBadge(msg); } catch(e){}
    if (_extBadgeWatchdog) return;
    _extBadgeWatchdog = setInterval(() => {
      if (!_extBadgeMsg) return;
      const badge = document.getElementById('lore-status-badge');
      if (badge && badge.style.opacity === '1' && (badge.textContent || '').includes(_extBadgeMsg)) return;
      try { C.showStatusBadge(_extBadgeMsg); } catch(e){}
    }, 1500);
  }
  function extBadgeHide() {
    _extBadgeMsg = null;
    if (_extBadgeWatchdog) { clearInterval(_extBadgeWatchdog); _extBadgeWatchdog = null; }
    try { C.hideStatusBadge(); } catch(e){}
  }
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && _extBadgeMsg) { try { C.showStatusBadge(_extBadgeMsg); } catch(e){} }
  });

  async function runAutoExtract(isManual = false) {
    if (_extQ.running) {
      if (isManual) throw new Error('이미 로어 추출이 진행 중입니다. 완료 후 다시 시도해 주세요.');
      _extQ.pendingTurns++;
      return;
    }
    _extQ.running = true; _extQ.pendingTurns = 0; _extQ.manualPending = false;
    extBadgeShow('에리가 대화 분석 중');
    try { await _doExtract(isManual); }
    finally {
      _extQ.running = false; extBadgeHide();
      if (_extQ.pendingTurns > 0 || _extQ.manualPending) { const nextManual = _extQ.manualPending; setTimeout(() => runAutoExtract(nextManual), 500); }
    }
  }

  async function _doExtract(isManual) {
    const _url = C.getCurUrl(); const chatKey = getChatKey();
    const apiType = settings.config.autoExtApiType || 'key';
    const missingReason = typeof _w.__LoreInj.getApiMissingReason === 'function'
      ? _w.__LoreInj.getApiMissingReason(settings.config, 'generate')
      : (apiType === 'vertex' ? (!settings.config.autoExtVertexJson && 'Vertex JSON 필요.')
        : apiType === 'firebase' ? (!settings.config.autoExtFirebaseScript && 'Firebase 설정 필요.')
        : apiType === 'deepseek' ? (!settings.config.autoExtDeepSeekKey && 'DeepSeek API 키 필요.')
        : (!settings.config.autoExtKey && 'Gemini API 키 필요.'));
    if (missingReason) { if (isManual) throw new Error(missingReason); return; }
    const scanR = isManual ? (settings.config.manualExtScanRange || settings.config.autoExtScanRange || 6) : (settings.config.autoExtScanRange || 6);
    const scanOffset = isManual
      ? (settings.config.manualExtOffset != null ? settings.config.manualExtOffset : (settings.config.autoExtOffset || 0))
      : (settings.config.autoExtOffset || 0);
    const topics = normalizeExtractTopics(isManual ? settings.config.manualExtractTopics : settings.config.autoExtractTopics);
    const extraTurns = _extQ.pendingTurns || 0;
    const effectiveRange = scanR + extraTurns; const fetchCount = (effectiveRange + scanOffset) * 2;
    let recentMsgs = await C.fetchLogs(fetchCount > 0 ? fetchCount : 20);
    if (!recentMsgs.length) { if (isManual) throw new Error('대화 기록 없음.'); return; }
    const offsetCount = scanOffset * 2;
    if (offsetCount > 0 && recentMsgs.length > offsetCount) recentMsgs = recentMsgs.slice(0, recentMsgs.length - offsetCount);
    const context = recentMsgs.map(m => m.role + ': ' + m.message).join('\n');
    const _patchOn = settings.config.autoExtIncludeDb && settings.config.autoExtPatchMode !== false;
    let entriesText = '[]';
    if (settings.config.autoExtIncludeDb) {
      const packName = await getAutoExtPackForUrl(_url);
      const existingEntries = await db.entries.where('packName').equals(packName).toArray();
      if (existingEntries.length > 0) {
        entriesText = buildExistingLoreContext(existingEntries, context, 20);
      }
    }
    let personaPrefix = '';
    if (settings.config.autoExtIncludePersona) {
      const pName = await C.fetchPersonaName();
      if (pName) personaPrefix = `[User Persona: "${pName}"] All "user" role messages are from this character. Use "${pName}" as the character name, NOT "user".\n\n`;
    }
    const tpl = settings.getActiveTemplate();
    const promptTpl = getLoreExtractPrompt(tpl, settings.config.autoExtIncludeDb, apiType);
    const extractSchema = buildExtractSchema(tpl);
    const outputModeText = settings.config.autoExtIncludeDb ? providerOutputMode(_patchOn ? OUTPUT_MODE_PATCH : OUTPUT_MODE_FULL, { apiType }, 'extract') : '';
    const shouldRunTemporalExtract = topics.majorScenes && settings.config.temporalExtractEnabled !== false &&
      (isManual || settings.config.temporalExtractAutoEnabled === true);
    const temporalCoordination = shouldRunTemporalExtract
      ? '\n\nRUNTIME COORDINATION: A dedicated scene-memory pass will run after this response. Do not output type="timeline_event" in this general pass.'
      : '';
    const prompt = personaPrefix + promptTpl.replace('{context}', context).replace('{entries}', entriesText).replace('{schema}', extractSchema).replace('{outputMode}', outputModeText) + buildExtractionScope(topics) + temporalCoordination;

    const _extModel = settings.config.autoExtModel === '_custom' ? settings.config.autoExtCustomModel : settings.config.autoExtModel;
    let apiLog = null, _extElapsedMs = 0, _extCost = null;
    try {
      const apiOpts = (_w.__LoreInj.buildGenerationApiOpts ? _w.__LoreInj.buildGenerationApiOpts({
        model: _extModel,
        maxRetries: settings.config.autoExtMaxRetries || 1, responseMimeType: 'application/json',
        timeoutMs: apiType === 'deepseek' ? 150000 : 120000,
        costContext: { feature: 'autoExtract', chatKey: chatKey || 'global' }
      }, { feature: 'autoExtract', chatKey: chatKey || 'global' }) : {
        apiType, key: settings.config.autoExtKey, deepSeekKey: settings.config.autoExtDeepSeekKey,
        deepSeekThinking: settings.config.autoExtDeepSeekThinking !== false, deepSeekReasoning: settings.config.autoExtDeepSeekReasoning || 'high',
        vertexJson: settings.config.autoExtVertexJson,
        vertexLocation: settings.config.autoExtVertexLocation || 'global', vertexProjectId: settings.config.autoExtVertexProjectId,
        firebaseScript: settings.config.autoExtFirebaseScript, firebaseEmbedKey: settings.config.autoExtFirebaseEmbedKey,
        model: _extModel,
        maxRetries: settings.config.autoExtMaxRetries || 1, responseMimeType: 'application/json',
        timeoutMs: apiType === 'deepseek' ? 150000 : 120000,
        costContext: { feature: 'autoExtract', chatKey: chatKey || 'global' }
      });
      const _extT0 = Date.now();
      const { res, parsed } = await callGeminiJsonWithRepair(prompt, apiOpts, 'Return the requested JSON shape only. For DeepSeek use {"entries":[...]} with no markdown.');
      _extElapsedMs = Date.now() - _extT0;
      _extCost = (res && res.cost) || null;
      apiLog = res ? { status: res.status, error: res.error, retries: res.retries } : null;
      if (!res || !res.text) throw new Error('AI 응답없음 (' + ((res && res.error) || '알수없음') + ')');
      if (!parsed) throw new Error('JSON 파싱 실패 (응답 스니포: ' + (res.text || '').slice(0, 100) + ')');
      const parsedItems = normalizeExtractItems(parsed);
      let generalCount = 0;
      let embedMsg = '';
      let embedCount = 0;
      let temporalCount = 0;
      let temporalResult = null;
      if (shouldRunTemporalExtract) {
        temporalResult = await collectTemporalExtractItems({ context, apiOpts, url: _url, chatKey, isManual, msgCount: recentMsgs.length, skipEmbedding: true });
      }

      const hasStagedChanges = parsedItems.length > 0 || !!(temporalResult && temporalResult.count > 0);
      if (hasStagedChanges) {
        const commitPackName = await getAutoExtPackForUrl(_url);
        const rollbackState = await snapshotPackState(commitPackName);
        try {
          const existingPack = await db.packs.get(commitPackName);
          if (existingPack) await createSnapshot(commitPackName, '자동 병합 전 백업', 'auto');
          if (parsedItems.length) generalCount = await mergeExtractedData(parsedItems, _url, { skipSnapshot: true });
          if (temporalResult) {
            for (const patch of (temporalResult.patches || [])) {
              temporalCount += await applyTemporalPatchOp(patch, commitPackName, chatKey);
            }
            if (temporalResult.events && temporalResult.events.length) {
              temporalCount += await mergeExtractedData(temporalResult.events, _url, { skipSnapshot: true });
            }
          }
        } catch (commitError) {
          try { await restorePackState(rollbackState); }
          catch (rollbackError) {
            commitError.message = (commitError.message || String(commitError)) + ' / 롤백 실패: ' + (rollbackError.message || String(rollbackError));
          }
          throw commitError;
        }
      }
      const generalStatus = parsedItems.length ? (generalCount > 0 ? '성공' : '변경 없음') : '추출 내용 없음';
      addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count: generalCount, msgs: recentMsgs.length, isManual, status: generalStatus, api: apiLog, model: _extModel, elapsedMs: _extElapsedMs, cost: _extCost });
      if (shouldRunTemporalExtract && temporalResult) {
        addExtLog(chatKey, {
          time: new Date().toLocaleTimeString(), count: temporalCount, msgs: recentMsgs.length, isManual,
          status: temporalCount > 0 ? '중요 장면 정리 성공' : '중요 장면 변경 없음',
          api: temporalResult.api || null, model: _extModel, elapsedMs: temporalResult.elapsedMs || 0, cost: temporalResult.cost || null
        });
      }
      const shouldEmbedAfterExtract = (generalCount + temporalCount) > 0 &&
        settings.config.embeddingEnabled && settings.config.autoEmbedOnExtract !== false;
      if (shouldEmbedAfterExtract) {
        try {
          const epName = await getAutoExtPackForUrl(_url);
          extBadgeShow('에리가 검색 준비 중');
          const embedOpts = _w.__LoreInj.buildEmbeddingApiOpts
            ? _w.__LoreInj.buildEmbeddingApiOpts({ model: settings.config.embeddingModel || 'gemini-embedding-001' }, { feature: 'embed', chatKey: chatKey || 'global' })
            : { ...apiOpts, apiType: apiType === 'deepseek' ? 'key' : apiType, key: apiType === 'deepseek' ? settings.config.autoExtFirebaseEmbedKey : settings.config.autoExtKey, model: settings.config.embeddingModel || 'gemini-embedding-001' };
          embedCount = await C.embedPack(epName, embedOpts);
          embedMsg = ' (검색 준비 ' + embedCount + '개 완료)';
        } catch(embErr) {
          console.warn('[Lore] 자동임베딩 실패:', embErr.message);
          embedMsg = ' (검색 준비 실패)';
        }
      }
      if (isManual) {
        const temporalMsg = shouldRunTemporalExtract
          ? ' / 중요 장면 ' + temporalCount + '개'
          : '';
        const baseMsg = generalCount > 0
          ? generalCount + '개 로어 추출 및 병합됨'
          : '새로운 일반 로어 없음';
        alert(baseMsg + temporalMsg + embedMsg + '.');
      }
    } catch (err) {
      addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count: 0, msgs: recentMsgs.length, isManual, status: '실패', error: err.message, api: apiLog, model: _extModel, elapsedMs: _extElapsedMs, cost: _extCost });
      if (isManual) throw err;
      console.warn('[Lore:auto-extract] 실패:', err);
    }
  }

  const BATCH_RETRY_STORAGE_KEY = 'lore-batch-extraction-jobs-v1';

  function readBatchRetryJobs() {
    try {
      const parsed = JSON.parse(_ls.getItem(BATCH_RETRY_STORAGE_KEY) || '{}');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch (_) { return {}; }
  }

  function getBatchRetryJob(chatKey = getChatKey()) {
    const job = readBatchRetryJobs()[chatKey || 'global'];
    if (!job || !Array.isArray(job.failedBatchIndexes) || !job.failedBatchIndexes.length) return null;
    return JSON.parse(JSON.stringify(job));
  }

  function saveBatchRetryJob(chatKey, job) {
    const key = chatKey || 'global';
    const jobs = readBatchRetryJobs();
    if (!job || !Array.isArray(job.failedBatchIndexes) || !job.failedBatchIndexes.length) delete jobs[key];
    else jobs[key] = { ...job, version: 1, chatKey: key, updatedAt: Date.now() };
    try { _ls.setItem(BATCH_RETRY_STORAGE_KEY, JSON.stringify(jobs)); }
    catch (e) { console.warn('[Lore:batch] 재시도 상태 저장 실패:', e); }
    return jobs[key] || null;
  }

  function clearBatchRetryJob(chatKey = getChatKey()) {
    return saveBatchRetryJob(chatKey, null);
  }

  function splitConversationBatches(allMsgs, turnsPerBatch, overlap) {
    const batchMsgSize = Math.max(2, Number(turnsPerBatch || 50) * 2);
    const overlapMsgs = Math.max(0, Number(overlap || 0) * 2);
    const step = Math.max(1, batchMsgSize - overlapMsgs);
    const batches = [];
    for (let i = 0; i < allMsgs.length; i += step) {
      const slice = allMsgs.slice(i, i + batchMsgSize);
      if (slice.length < 2) break;
      batches.push(slice);
      if (i + batchMsgSize >= allMsgs.length) break;
    }
    return batches;
  }

  function addBatchCost(total, cost) {
    if (!cost) return;
    if (cost.usd != null) { total.usd += Number(cost.usd) || 0; total.known = true; }
    else total.hasUnknown = true;
    if (cost.estimated) total.estimated = true;
  }

  async function runBatchExtractResumable(opts = {}) {
    try {
    const turnsPerBatch = Math.max(1, Number(opts.turnsPerBatch || 50));
    const overlap = Math.max(0, Number(opts.overlap !== undefined ? opts.overlap : 5));
    const maxAttempts = Math.max(1, Number(opts.maxAttempts || 3));
    const onlyBatchIndexes = Array.isArray(opts.onlyBatchIndexes)
      ? Array.from(new Set(opts.onlyBatchIndexes.map(Number).filter(Number.isInteger)))
      : null;
    const onProgress = typeof opts.onProgress === 'function' ? opts.onProgress : null;
    const apiType = settings.config.autoExtApiType || 'key';
    const isDeepSeek = apiType === 'deepseek';
    const timeoutMs = isDeepSeek ? 150000 : 90000;
    const chatKey = getChatKey() || 'global';
    const url = C.getCurUrl();
    const topics = normalizeExtractTopics(opts.topics || settings.config.manualExtractTopics);
    const missingReason = typeof _w.__LoreInj.getApiMissingReason === 'function'
      ? _w.__LoreInj.getApiMissingReason(settings.config, 'generate')
      : '';
    if (missingReason) throw new Error(missingReason);

    extBadgeShow('에리가 전체 대화 가져오는 중');
    const allMsgs = await C.fetchLogs(99999);
    if (!allMsgs || !allMsgs.length) { extBadgeHide(); throw new Error('대화 기록 없음'); }
    const batches = splitConversationBatches(allMsgs, turnsPerBatch, overlap);
    const selected = onlyBatchIndexes
      ? new Set(onlyBatchIndexes.filter(index => index >= 1 && index <= batches.length))
      : new Set(batches.map((_, index) => index + 1));
    if (!selected.size) { extBadgeHide(); throw new Error('다시 시도할 대화 구간이 없음'); }

    const priorJob = getBatchRetryJob(chatKey);
    const unresolved = new Set(onlyBatchIndexes && priorJob ? priorJob.failedBatchIndexes : []);
    const report = {
      totalBatches: batches.length,
      attemptedBatches: selected.size,
      totalMsgs: allMsgs.length,
      ok: 0,
      failed: 0,
      empty: 0,
      entriesAdded: 0,
      failedBatchIndexes: [],
      batchResults: []
    };
    const batchCost = { usd: 0, known: false, hasUnknown: false, estimated: false };
    const startedAt = Date.now();
    const model = settings.config.autoExtModel === '_custom' ? settings.config.autoExtCustomModel : settings.config.autoExtModel;
    const template = settings.getActiveTemplate();
    const promptTemplate = getLoreExtractPrompt(template, settings.config.autoExtIncludeDb, apiType);
    const extractSchema = buildExtractSchema(template);
    const patchOn = settings.config.autoExtIncludeDb && settings.config.autoExtPatchMode !== false;
    const runTemporal = topics.majorScenes && settings.config.temporalExtractEnabled !== false && settings.config.temporalExtractBatchEnabled === true;
    let personaPrefix = '';
    if (settings.config.autoExtIncludePersona) {
      try {
        const personaName = await C.fetchPersonaName();
        if (personaName) personaPrefix = '[User Persona: "' + personaName + '"] All "user" role messages are from this character. Use "' + personaName + '" as the character name, NOT "user".\n\n';
      } catch (_) {}
    }

    const successfulStages = [];
    for (let batchIndex = 1; batchIndex <= batches.length; batchIndex++) {
      if (!selected.has(batchIndex)) continue;
      const messages = batches[batchIndex - 1];
      extBadgeShow('에리가 대화 구간 ' + batchIndex + '/' + batches.length + ' 분석 중');
      if (onProgress) { try { onProgress({ phase: 'batch', index: batchIndex, total: batches.length }); } catch (_) {} }
      const context = messages.map(message => message.role + ': ' + message.message).join('\n');
      let entriesText = '[]';
      if (settings.config.autoExtIncludeDb) {
        const packName = await getAutoExtPackForUrl(url);
        const existing = await db.entries.where('packName').equals(packName).toArray();
        if (existing.length) entriesText = buildExistingLoreContext(existing, context, 20);
      }
      const outputMode = settings.config.autoExtIncludeDb
        ? providerOutputMode(patchOn ? OUTPUT_MODE_PATCH : OUTPUT_MODE_FULL, { apiType }, 'extract')
        : '';
      const temporalCoordination = runTemporal
        ? '\n\nRUNTIME COORDINATION: A dedicated scene-memory pass will run after this response. Do not output type="timeline_event" in this general pass.'
        : '';
      const prompt = personaPrefix + promptTemplate
        .replace('{context}', context)
        .replace('{entries}', entriesText)
        .replace('{schema}', extractSchema)
        .replace('{outputMode}', outputMode)
        + buildExtractionScope(topics)
        + temporalCoordination;

      let generalItems = null;
      let generalError = '';
      let generalAttempts = 0;
      for (let attempt = 1; attempt <= maxAttempts && generalItems === null; attempt++) {
        generalAttempts = attempt;
        if (attempt > 1) await new Promise(resolve => setTimeout(resolve, Math.min(8000, 1000 * Math.pow(2, attempt - 2)) + Math.random() * 400));
        try {
          const feature = onlyBatchIndexes ? 'batchExtractRetry' : 'batchExtract';
          const apiOpts = _w.__LoreInj.buildGenerationApiOpts({
            model,
            maxRetries: 0,
            responseMimeType: 'application/json',
            timeoutMs,
          }, { feature, chatKey });
          const { res, parsed } = await callGeminiJsonWithRepair(prompt, apiOpts, 'Return the requested JSON shape only. For DeepSeek use {"entries":[...]} with no markdown.');
          addBatchCost(batchCost, res && res.cost);
          if (!res || !res.text) throw new Error('API 응답 없음 (' + ((res && res.error) || '알 수 없음') + ')');
          if (!parsed) throw new Error('JSON 파싱 실패: ' + String(res.text).slice(0, 160));
          generalItems = normalizeExtractItems(parsed);
        } catch (error) {
          generalError = error && error.message ? error.message : String(error);
        }
      }

      if (generalItems === null) {
        report.failed++;
        report.failedBatchIndexes.push(batchIndex);
        unresolved.add(batchIndex);
        report.batchResults.push({ batch: batchIndex, status: 'failed', attempts: generalAttempts, error: generalError });
        addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count: 0, msgs: messages.length, isManual: true, status: '전체 추출 구간 ' + batchIndex + '/' + batches.length + ' 실패', error: generalError, model });
        continue;
      }

      let temporalResult = null;
      let temporalError = '';
      let temporalAttempts = 0;
      if (runTemporal) {
        for (let attempt = 1; attempt <= maxAttempts && temporalResult === null; attempt++) {
          temporalAttempts = attempt;
          if (attempt > 1) await new Promise(resolve => setTimeout(resolve, Math.min(8000, 1000 * Math.pow(2, attempt - 2)) + Math.random() * 400));
          try {
            extBadgeShow('에리가 대화 구간 ' + batchIndex + '/' + batches.length + ' 중요 장면 분석 중');
            const feature = onlyBatchIndexes ? 'batchExtractRetry' : 'batchExtract';
            const apiOpts = _w.__LoreInj.buildGenerationApiOpts({
              model,
              maxRetries: 0,
              responseMimeType: 'application/json',
              timeoutMs,
            }, { feature, chatKey });
            temporalResult = await collectTemporalExtractItems({ context, apiOpts, url, chatKey, isManual: true, msgCount: messages.length, skipEmbedding: true });
            addBatchCost(batchCost, temporalResult && temporalResult.cost);
          } catch (error) {
            temporalError = error && error.message ? error.message : String(error);
          }
        }
      }

      if (runTemporal && temporalResult === null) {
        report.failed++;
        report.failedBatchIndexes.push(batchIndex);
        unresolved.add(batchIndex);
        report.batchResults.push({ batch: batchIndex, status: 'temporal_failed', attempts: temporalAttempts, error: temporalError });
        addExtLog(chatKey, { time: new Date().toLocaleTimeString(), count: 0, msgs: messages.length, isManual: true, status: '전체 추출 구간 ' + batchIndex + '/' + batches.length + ' 중요 장면 실패', error: temporalError, model });
        continue;
      }

      const temporalCount = temporalResult ? Number(temporalResult.count || 0) : 0;
      successfulStages.push({ batchIndex, generalItems, temporalResult });
      unresolved.delete(batchIndex);
      if (generalItems.length || temporalCount) report.ok++;
      else report.empty++;
      report.batchResults.push({ batch: batchIndex, status: generalItems.length || temporalCount ? 'ok' : 'empty', attempts: generalAttempts, entries: generalItems.length + temporalCount });
    }

    if (successfulStages.length) {
      const packName = await getAutoExtPackForUrl(url);
      const rollbackState = await snapshotPackState(packName);
      try {
        const generalItems = successfulStages.flatMap(stage => stage.generalItems || []);
        const temporalPatches = successfulStages.flatMap(stage => stage.temporalResult && stage.temporalResult.patches || []);
        const temporalEvents = successfulStages.flatMap(stage => stage.temporalResult && stage.temporalResult.events || []);
        if (generalItems.length) report.entriesAdded += await mergeExtractedData(generalItems, url);
        for (const temporalPatch of temporalPatches) report.entriesAdded += await applyTemporalPatchOp(temporalPatch, packName, chatKey);
        if (temporalEvents.length) report.entriesAdded += await mergeExtractedData(temporalEvents, url);
      } catch (commitError) {
        try { await restorePackState(rollbackState); }
        catch (rollbackError) { commitError.message += ' / 롤백 실패: ' + (rollbackError.message || String(rollbackError)); }
        extBadgeHide();
        throw commitError;
      }
    }

    if (report.entriesAdded > 0 && settings.config.embeddingEnabled && settings.config.autoEmbedOnExtract !== false) {
      try {
        if (onProgress) { try { onProgress({ phase: 'embedding' }); } catch (_) {} }
        const packName = await getAutoExtPackForUrl(url);
        extBadgeShow('에리가 검색 준비 중');
        const embedOpts = _w.__LoreInj.buildEmbeddingApiOpts({ model: settings.config.embeddingModel || 'gemini-embedding-001' }, { feature: 'embed', chatKey });
        await C.embedPack(packName, embedOpts);
        report.embedded = true;
      } catch (error) {
        report.embedError = error && error.message ? error.message : String(error);
      }
    }

    const remainingFailed = Array.from(unresolved).filter(index => index >= 1 && index <= batches.length).sort((a, b) => a - b);
    report.failedBatchIndexes = remainingFailed;
    report.failed = remainingFailed.length;
    const job = remainingFailed.length ? {
      url,
      turnsPerBatch,
      overlap,
      maxAttempts,
      totalBatches: batches.length,
      totalMsgs: allMsgs.length,
      failedBatchIndexes: remainingFailed,
      batchErrors: report.batchResults.filter(result => /failed/.test(result.status)).map(result => ({ batch: result.batch, error: result.error || '' })),
      lastEntriesAdded: report.entriesAdded
    } : null;
    saveBatchRetryJob(chatKey, job);
    addExtLog(chatKey, {
      time: new Date().toLocaleTimeString(),
      count: report.entriesAdded,
      msgs: allMsgs.length,
      isManual: true,
      status: remainingFailed.length
        ? '전체 추출 일부 완료 (성공 ' + (report.ok + report.empty) + ' / 다시 시도 ' + remainingFailed.length + ')'
        : '전체 추출 완료 (' + batches.length + '개 구간)',
      model,
      elapsedMs: Date.now() - startedAt,
      cost: { usd: batchCost.known ? batchCost.usd : null, estimated: batchCost.estimated, hasUnknown: batchCost.hasUnknown, isBatchAggregate: true }
    });
      return report;
    } finally {
      extBadgeHide();
    }
  }

  Object.assign(_w.__LoreInj, {
    mergeExtractedData, runAutoExtract, runBatchExtract: runBatchExtractResumable, runTemporalExtractPass,
    getBatchRetryJob, clearBatchRetryJob, buildExtractionScope, normalizeExtractTopics,
    extBadgeShow, extBadgeHide,
    __extractLoaded: true
  });
  console.log('[LoreInj:4] extract loaded');
})();
