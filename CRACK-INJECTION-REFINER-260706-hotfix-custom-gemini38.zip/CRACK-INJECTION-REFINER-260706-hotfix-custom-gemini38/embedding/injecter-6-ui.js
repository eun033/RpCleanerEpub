// injecter-6-ui.js: UI 진입점 (모달 생성 + DOM 주입 + 기어 버튼)
(async function(){
  'use strict';
  const _w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
  const _ls = _w.localStorage;

  function isChatPath() {
    const fn = _w.__LoreInj && _w.__LoreInj.isChatPath;
    if (typeof fn === 'function') {
      try { return !!fn(); } catch (_) {}
    }
    return /\/characters\/[a-f0-9]+\/chats\/[a-f0-9]+/.test(location.pathname)
      || /\/stories\/[a-f0-9]+\/episodes\/[a-f0-9]+/.test(location.pathname)
      || /\/u\/[a-f0-9]+\/c\/[a-f0-9]+/.test(location.pathname);
  }

  function reloadOnSpaChatRoute() {
    if (!_w.__LoreInj || typeof _w.__LoreInj.runWhenChatRoute !== 'function') return;
    _w.__LoreInj.runWhenChatRoute(() => {
      if (_w.__LoreInj.__uiLoaded || _w.__LoreInj.__spaChatReloading) return;
      _w.__LoreInj.__spaChatReloading = true;
      console.log('[LoreInj:6-ui] SPA chat route detected after light boot: reload for full bootstrap');
      setTimeout(() => location.reload(), 50);
    });
  }

  async function showBootErrorBadge(gate) {
    if (document.readyState === 'loading') await new Promise(r => document.addEventListener('DOMContentLoaded', r));
    if (document.getElementById('lore-inj-boot-error')) return;
    const btn = document.createElement('button');
    btn.id = 'lore-inj-boot-error';
    btn.textContent = '로어 도구 로딩 오류';
    btn.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:999999;background:#833;color:#fff;border:0;border-radius:8px;padding:8px 10px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,.35);';
    btn.onclick = () => {
      const L = _w.__LoreInj || {};
      const payload = { gate, moduleStatus: L.moduleStatus || {}, missingSubs: L.missingSubs || [], menuOrder: L.__menuOrder || null, route: L.route || null };
      alert(('로어 도구 일부가 아직 준비되지 않았습니다. 페이지를 새로고침한 뒤 다시 열어 주세요.\n\n상세 정보:\n' + JSON.stringify(payload, null, 2)).slice(0, 3000));
    };
    document.body.appendChild(btn);
  }

  async function waitForModalManager(timeoutMs = 10000) {
    const until = Date.now() + timeoutMs;
    while (Date.now() < until) {
      const MM = (typeof ModalManager !== 'undefined') ? ModalManager
              : (_w.ModalManager || (typeof window !== 'undefined' && window.ModalManager) || null);
      if (MM) return MM;
      await new Promise(r => setTimeout(r, 100));
    }
    return null;
  }

  // 1) 로더가 노출한 ready 게이트를 먼저 기다린다 (코어 5 + 서브 11 전원 로드 확인).
  //    게이트가 없으면(구버전 로더) 기존 폴링 로직으로 폴백.
  if (_w.__LoreInjReady && typeof _w.__LoreInjReady.then === 'function') {
    const gate = await _w.__LoreInjReady;
    if (!gate || gate.ok !== true) {
      console.error('[LoreInj:6-ui] ready 게이트 실패, UI 마운트 중단:', gate);
      await showBootErrorBadge(gate);
      return;
    }
  } else {
    const _deadline = Date.now() + 15000;
    const _subs = ['__interceptorLoaded','__constLoaded','__settingsLoaded','__extractLoaded','__injectLoaded','__subMainLoaded','__subLoreLoaded','__subMergeLoaded','__subSnapshotLoaded','__subFileLoaded','__subBackupLoaded','__subExtractLoaded','__subRefinerLoaded','__subLogLoaded','__subSessionLoaded','__subApiLoaded','__subHelpLoaded'];
    while (Date.now() < _deadline) {
      const L = _w.__LoreInj;
      if (L && _subs.every(k => L[k])) break;
      await new Promise(r => setTimeout(r, 50));
    }
    const L = _w.__LoreInj;
    if (!L || !_subs.every(k => L[k])) { console.error('[LoreInj:6-ui] 폴백 대기 타임아웃, UI 마운트 중단'); await showBootErrorBadge({ ok: false, reason: 'fallback-timeout' }); return; }
  }

  if (!isChatPath()) {
    console.log('[LoreInj:6-ui] non-chat route: UI bootstrap skipped');
    reloadOnSpaChatRoute();
    return;
  }

  // 2) 게이트 통과 후 DOM 준비 대기.
  if (document.readyState === 'loading') await new Promise(r => document.addEventListener('DOMContentLoaded', r));

  if (_w.__LoreInj.__uiLoaded) return;

  const { C, R, settings } = _w.__LoreInj;
  const VER = _w.__LoreInj.VER;
  const ENTRY_BUTTON_ID = 'lore-inj-entry-button';
  const ENTRY_BUTTON_CLASS = 'lore-inj-entry-button';

  // ModalManager 해결
  const MM = await waitForModalManager(10000);
  if (!MM) {
    console.error('[LoreInj:6-ui] ModalManager 미로드');
    _w.__LoreInj?.markFailed?.('ui', 'ModalManager missing');
    await showBootErrorBadge({ ok: false, reason: 'ModalManager missing' });
    return;
  }

  // 서브모듈 등록은 ready 게이트에서 이미 보장됨 (이중 폴링 제거).

  const modal = MM.getOrCreateManager('c2');
  if (!modal || typeof modal.createMenu !== 'function') {
    console.error('[LoreInj:6-ui] modal.createMenu 없음');
    _w.__LoreInj?.markFailed?.('ui', 'modal.createMenu missing');
    await showBootErrorBadge({ ok: false, reason: 'modal.createMenu missing' });
    return;
  }

  // 메뉴 등록 함수 호출. createSubMenu 호환 처리는 injecter-6의 adapter가 담당한다.
  if (_w.__LoreInj.setupSubMenus) {
    _w.__LoreInj.setupSubMenus(modal);
  }

  function openLoreModal() {
    const manager = MM.getOrCreateManager('c2');
    try { C.ensureLoreModalStyles && C.ensureLoreModalStyles(); } catch (_) {}
    manager.display(document.body.getAttribute('data-theme') !== 'light');
    try {
      const opened = manager.getOpened && manager.getOpened();
      const container = opened && opened.__container;
      if (container && container.classList) container.classList.add('lore-inj-modal');
    } catch (_) {}
  }

  function isElementVisible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden';
  }

  function visibleButtonLikes(root) {
    const scope = root && root.querySelectorAll ? root : document;
    return Array.from(scope.querySelectorAll('button,a,[role="button"]')).filter(isElementVisible);
  }

  function createEntryButton() {
    const btn = document.createElement('button');
    btn.id = ENTRY_BUTTON_ID;
    btn.type = 'button';
    btn.className = ENTRY_BUTTON_CLASS;
    btn.setAttribute('data-lore-inj-entry', 'true');
    btn.textContent = 'Lore';
    btn.title = '로어 인젝터 열기';
    btn.setAttribute('aria-label', '로어 인젝터 열기');
    btn.style.cssText = [
      'height:32px',
      'min-width:0',
      'padding:0 10px',
      'border:1px solid rgba(127,127,127,.35)',
      'border-radius:999px',
      'background:rgba(127,127,127,.08)',
      'color:inherit',
      'font-size:12px',
      'font-weight:700',
      'line-height:1',
      'display:inline-flex',
      'align-items:center',
      'justify-content:center',
      'white-space:nowrap',
      'cursor:pointer',
      'margin-right:6px',
      'box-sizing:border-box'
    ].join(';');
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      openLoreModal();
    });
    return btn;
  }

  function mountFloatingEntryButton() {
    if (document.getElementById(ENTRY_BUTTON_ID)) return false;
    const btn = createEntryButton();
    btn.style.cssText += [
      'position:fixed',
      'right:12px',
      'bottom:calc(76px + env(safe-area-inset-bottom, 0px))',
      'z-index:2147483646',
      'height:34px',
      'min-width:52px',
      'margin:0',
      'box-shadow:0 4px 14px rgba(0,0,0,.35)',
      'backdrop-filter:blur(8px)'
    ].join(';');
    document.body.appendChild(btn);
    return true;
  }

  function mountEntryButton(target) {
    if (!target || !target.host || document.getElementById(ENTRY_BUTTON_ID)) return false;
    const btn = createEntryButton();
    const before = target.before && target.before.parentElement === target.host ? target.before : null;
    if (before) target.host.insertBefore(btn, before);
    else target.host.appendChild(btn);
    return true;
  }

  // === DOM 진입점 ===
  // 1) 좌측 설정 메뉴에 "결정화 캐즘" 링크 추가
  function __updateModalMenu() {
    const modalEl = document.getElementById('web-modal');
    if (modalEl && !document.getElementById('chasm-decentral-menu')) {
      const itemFound = modalEl.getElementsByTagName('a');
      for (let item of itemFound) {
        if (item.getAttribute('href') === '/setting') {
          const clonedElement = item.cloneNode(true);
          clonedElement.id = 'chasm-decentral-menu';
          const textElement = clonedElement.getElementsByTagName('span')[0];
          if (textElement) textElement.innerText = '결정화 캐즘';
          clonedElement.setAttribute('href', 'javascript: void(0)');
          clonedElement.onclick = (event) => {
            event.preventDefault(); event.stopPropagation();
            openLoreModal();
          };
          item.parentElement?.append(clonedElement);
          break;
        }
      }
    }
  }

  function findLegacyBannerTarget() {
    const isStory = /\/stories\/[a-f0-9]+\/episodes\/[a-f0-9]+/.test(location.pathname) || /\/u\/[a-f0-9]+\/c\/[a-f0-9]+/.test(location.pathname);
    const topPanel = document.getElementsByClassName(isStory ? 'css-1c5w7et' : 'css-l8r172');
    if (!topPanel || topPanel.length <= 0) return null;
    try {
      const topContainer = topPanel[0].childNodes[topPanel.length - 1]?.getElementsByTagName('div');
      if (!topContainer || topContainer.length <= 0) return null;
      const topList = topContainer[0].children[0].children;
      const top = topList[topList.length - 1];
      return top ? { host: top, before: top.childNodes[0] || null } : null;
    } catch(e) {
      return null;
    }
  }

  function findModernHeaderTarget() {
    const minLeft = Math.max(260, Math.floor(window.innerWidth * 0.35));
    const controls = visibleButtonLikes(document)
      .filter(el => {
        const r = el.getBoundingClientRect();
        return r.top >= 48 && r.top <= 125 && r.left >= minLeft && r.right <= window.innerWidth + 8;
      })
      .sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);

    for (const control of controls) {
      let node = control.parentElement;
      while (node && node !== document.body) {
        const r = node.getBoundingClientRect();
        if (r.top >= 40 && r.top <= 130 && r.height >= 28 && r.height <= 72 &&
            r.width > 28 && r.width <= Math.min(620, window.innerWidth * 0.5) &&
            r.right >= window.innerWidth * 0.55) {
          const childControls = visibleButtonLikes(node)
            .filter(child => {
              const cr = child.getBoundingClientRect();
              return cr.top >= 40 && cr.top <= 130;
            })
            .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
          if (childControls.length > 0) return { host: node, before: childControls[0] };
        }
        node = node.parentElement;
      }
    }
    return null;
  }

  function findComposerToolbarTarget() {
    const editors = Array.from(document.querySelectorAll('[contenteditable="true"], .ProseMirror'))
      .filter(isElementVisible)
      .sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
    for (const editor of editors) {
      let node = editor.parentElement;
      while (node && node !== document.body) {
        const r = node.getBoundingClientRect();
        if (r.bottom >= window.innerHeight - 160 && r.height <= 220 && r.width >= 280) {
          const bottomControls = visibleButtonLikes(node)
            .filter(child => child.getBoundingClientRect().top >= editor.getBoundingClientRect().bottom - 4)
            .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
          if (bottomControls.length > 0) return { host: bottomControls[0].parentElement || node, before: bottomControls[0] };
        }
        node = node.parentElement;
      }
    }
    return null;
  }

  // 2) 채팅창 헤더/입력 영역에 컴팩트 진입 버튼 삽입
  async function injectBannerButton() {
    if (document.getElementById(ENTRY_BUTTON_ID)) return;
    const targets = [
      findLegacyBannerTarget(),
      findModernHeaderTarget(),
      findComposerToolbarTarget()
    ];
    for (const target of targets) {
      if (mountEntryButton(target)) return;
    }
    mountFloatingEntryButton();
  }

  async function doInjection() {
    if (!/\/characters\/[a-f0-9]+\/chats\/[a-f0-9]+/.test(location.pathname) && !/\/stories\/[a-f0-9]+\/episodes\/[a-f0-9]+/.test(location.pathname) && !/\/u\/[a-f0-9]+\/c\/[a-f0-9]+/.test(location.pathname)) return;
    await injectBannerButton();
  }

  function __doModalMenuInit() {
    if (document.c2InjectorModalInit) return;
    document.c2InjectorModalInit = true;
    // v1.4.0-test.39 B10 fix: body 전역 mutation에 매번 동기 실행되는 비용 회피.
    //   __updateModalMenu는 200ms debounce. 메뉴 DOM 변동은 SPA 라우팅 외 거의 없음.
    let _menuDebounceTimer = 0;
    const _debouncedUpdateMenu = () => {
      if (_menuDebounceTimer) return;
      _menuDebounceTimer = setTimeout(() => { _menuDebounceTimer = 0; __updateModalMenu(); }, 200);
    };
    if (typeof GenericUtil !== 'undefined' && GenericUtil.attachObserver) {
      GenericUtil.attachObserver(document, _debouncedUpdateMenu);
    } else {
      const observer = new MutationObserver(_debouncedUpdateMenu);
      observer.observe(document.body, { childList: true, subtree: true });
    }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', doInjection); window.addEventListener('load', doInjection); } else { doInjection(); }
    setInterval(doInjection, 2000);
  }

  document.getElementById('lore-inj-gear-btn')?.remove();
  __doModalMenuInit();

  Object.assign(_w.__LoreInj, { __uiLoaded: true });
  console.log('[LoreInj:6-ui] UI loaded (Chasm Tools banner attached)');
})();
